var express = require('express');
var router = express.Router();
var elasticsearchdetails = require('./configdetails/elasticsearchdetails');

var terms = new Set();

router.post('/Get/', function(req, res, next) {
    res.term = {}
    var terms = new Set();
    var query = req.body.query;
    elasticsearchdetails.client.search({
        index: 'questions_so',
        size: 10,
        type: 'question',
        _source: ['Id', 'Title', 'Body', 'Tags'],
        body: {
          query: {
            match: {'Title': query}
          },
        }
      },function (error, resp,status) {
        if (error){
          console.log("search error: "+error)
          res.send(error);
        }
        else {
            const arr = resp.hits.hits;
            for (var i = 0; i < arr.length; i++) {
                var temp = arr[i]['_source']['Tags'];
                var temp1 = temp.split(/<|>/);
                //console.log(temp1);
                for (var j = 0; j < temp1.length; j++) {
                    if (temp1[j]) {
                        terms.add(temp1[j]);
                    }
                }
            }
            //res.set('Content-Type', 'text/plain');
            var setArr = Array.from(terms);
            //console.log(setArr);
            //console.log(JSON.stringify(setArr));
            res.send(setArr);
        }
      });
});
module.exports = router;
