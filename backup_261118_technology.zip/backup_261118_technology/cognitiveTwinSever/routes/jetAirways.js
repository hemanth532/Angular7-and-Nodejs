var express = require('express');
var router = express.Router();
var elasticsearchdetails = require('./configdetails/elasticsearchdetails');
var Client = require('node-rest-client').Client;

function getQuery(index, type, source, match){
    return new Promise( function(resolve, reject){
        resolve( elasticsearchdetails.client.search({
            index: index,
            size: 10,
            type: type,
            _source: source,
            body: {
              query: {
                match: match
              },
            }
        })
        )
    })
}

router.get('/getAreas', function(req, res, next){
    res.send([
        "Sqldata log",
        "Reedem fly",
        "login",
        "consent",
        "miles",
        "claim voucher",
        "enroll",
        "Reedem miles",
        "Reedem",
        "login",
        "other",
        "Website unavailability"
    ]);
});


router.post('/get/',async function(req, res, next){
    var query = req.body.query;
     var jetAirwaysResp = await getQuery("jet_airways","data",['Description','created_date','Ref_Id','Quick_Fix','Resolution','last_occurred_on','Count_till_date','Areas','Sub_areas','RCA','link'],{'Description':query}).catch(err => {
         res.send(err);
     });
     var jetAirwaysList = jetAirwaysResp.hits.hits;
     if(jetAirwaysList && jetAirwaysList.length>0){
         for(var i = 0; i < jetAirwaysList.length; i++){
             var _source = jetAirwaysList[i]["_source"];
             if(_source.hasOwnProperty('link')){
                 var linkStr = _source['link'];
                 var linkArr = linkStr.split(/<|>/);
                 //console.log(linkArr.filter(Boolean));
                 jetAirwaysList[i]["_source"]["link"] = linkArr.filter(Boolean);
             }
             else{
                jetAirwaysList[i]["_source"]["link"] = [];
             }
        }
     }
     res.send(jetAirwaysResp.hits.hits);
})

module.exports = router;