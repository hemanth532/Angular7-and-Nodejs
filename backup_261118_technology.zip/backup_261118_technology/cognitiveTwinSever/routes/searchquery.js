var express = require('express');
var router = express.Router();
var elasticsearchdetails = require('./configdetails/elasticsearchdetails');
var Client = require('node-rest-client').Client;
var clientModel = new Client(); 
var application = require('../public/application.properties');
var arePinned = function(questions,userId){
  var len = questions.length;
  elasticsearchdetails.client.search({
    index: 'pin_results',
    type: 'save_results',
    size: 20,
    _source: ['questionId','title', 'questionBody','answerBody','isPinned','rating'],
    body: {
      query: {
        match: {'userId': userId }
      },
    }
  }, function(err, resp, status){
    if(err){
      res.send(err);
    } else {
      pinnedQuestions = resp.hits.hits;
      for(var i=0; i<len; i++){
        var question_json_id = questions[i]["_source"]["Id"];
        for(var j=0; j<pinnedQuestions.length; j++){
          var pinnedJson = pinnedQuestions[j];
          var pinnedSource = pinnedJson["_source"];
          var pinnedId = pinnedSource["questionId"];
          if(question_json_id == pinnedId){
            questions[i]["_source"]["isPinned"] = pinnedSource["isPinned"];
          }
          else{
            questions[i]["_source"]["isPinned"] = false;
          }
        }
      }
      //res.send(resp);
    }
  });
  return questions;
}

router.post('/getQuestions/', function(req, res, next) {
    var query = req.body.query;
    var userId = req.body.userId;
    elasticsearchdetails.client.search({
        index: 'questions_so',
        size: 10,
        type: 'question',
        _source: ['Id', 'Title', 'Body', 'Tags'],
        body: {
          query: {
            match: {'Title': query}
          },
        }
      }, function(err, resp, status){
          if(err){
              console.log(err);
              res.send(err);
          }
          else{
           // questions = resp.hits.hits;
           // resp.hits.hits = arePinned(questions,userId);
              res.json({
                  'response':resp
              });
          }
        }
      );
});

var get_answer = function(question_id, answer1)
{
  return elasticsearchdetails.client.search({
    index: 'answers_so',
    type: 'answer',
    size: 20,
    _source: ['Body', 'ParentId', 'Id'],
    body: {
      query: {
        match: {
          'ParentId': question_id
        },
      }
    }
  });
}

router.post('/getAnswers/', function(req, res, next) {
  var response = req.body.response;
  var jString = JSON.stringify(response);
  var obj = JSON.parse(jString);
  var question = obj.hits.hits;
  //console.log(question);
  var len = question.length;
  var answer1 = [];
  var answers = new Array();
  var j = 0;
  for (var i = 0; i < question.length; i++){
    get_answer(question[i]._source.Id, answer1).then(function(success, error){
      if(success){
        var jString1 = JSON.stringify(success);
        var obj1 = JSON.parse(jString1);
        var arr1 = obj1.hits.hits;
        //console.log(arr1);
        //console.log("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$")
        if(arr1 && arr1.length>0 && arr1[0].hasOwnProperty('_source')){
          answers.push(arr1[0]._source);
        }
        /*else{
          arr1[0]["_source"] = {
            'ParentId': question[i]._source.Id,
            'Id': "no_id",
            'Body': "Sorry !!! Nobody Ever answered this question."
          }
          console.log(arr1[0]["_source"]);
          answers.push(arr1[0]["_source"]);
        }*/
      }
      else{
        console.log(error);
        res.send(error);
      }
      answer1 = answers;
      j++;
      if(j==len){
        res.json({
          "response":answer1
        })
      }
    });
    
  }
  
});

router.post('/getPinStatus/', function(req, res, next){
  var pinQues = req.body.pinQues;
  var queryQues = req.body.queryQues;
  var pinQuesList = pinQues.hits.hits;
  var queryQuesList = queryQues.hits.hits;
  var flag = 0;
  for(var i=0; i<queryQuesList.length; i++){
    var queryQuesId = queryQuesList[i]["_source"]["Id"];
    for(var j=0; j<pinQuesList.length; j++){
      var pinQuesId = pinQuesList[j]["_source"]["questionId"];
      if(queryQuesId == pinQuesId){
        queryQuesList[i]["_source"]["isPinned"]="true";
        flag = 1;
        break;
      }
    }
    if(!flag){
      queryQuesList[i]["_source"]["isPinned"]="false";
    }
    flag = 0;
    var json_unOrder = queryQuesList[i]["_source"];
    var json_order = JSON.parse(JSON.stringify( json_unOrder, ["Tags","Body","Id","Title","isPinned"]));
    queryQuesList[i]["_source"] = json_order;
  }
  queryQues.hits.hits = queryQuesList;
  //console.log(queryQuesList);
  res.json({
    "response": queryQues
  });
});

router.post('/toModels/', function(req, res, next) {
  var list = req.body.response;
  console.log(list.hits.hits);
  var tech = req.body.tech;
  var query = req.body.query;
  var args = {
    data: {
      "list":list,
      "tech":tech,
      "query":query
    }, 
    headers: { "Content-Type": "application/json" }
  };
  //console.log(tech=='AWS');
  //console.log(tech)
  //console.log(list.hits.hits);
  if(tech=='AWS'){
    console.log("here --------");
    var req = clientModel.post(application.properties.modelURL, args, function (data, resp) {
      //var arr = data;
      //console.log(JSON.stringify(arr));
      //console.log(data.response.hits.hits);
      console.log("there --------------")
      res.send(data)
    });
    req.on('error', function (err) {
      console.log("|||||||||||||||||||||||||||||||||||||||||||||||||||");
      console.log('request error', err);
      //res.send(err);
      res.json({
        "response":list
      });
    });
  }
  else{
    res.json({
      "response":list
    });
  }
});

module.exports = router;