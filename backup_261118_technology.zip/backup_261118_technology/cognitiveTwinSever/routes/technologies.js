var express = require('express');
var router = express.Router();

router.get('/', function(req, res, next) {
    var arr = ['Asp.net','CSS','SQL','C','AWS','Default'];
      listOfTech = Array.from(arr);
      res.send(arr);
  });
  
  module.exports = router;