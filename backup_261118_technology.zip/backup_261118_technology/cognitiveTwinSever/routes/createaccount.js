var express = require('express');
var router = express.Router();
var sqldbcon = require('./configdetails/sqldbdetails');

router.post('/user/registration/', function(req, res, next) {
   console.log('Hemanth'+JSON.stringify(req.body));
   var contact_no = (req.body.contact_no).toString();
   req.body.contact_no = contact_no;
    var values = [req.body.email_id,
        req.body.pass_key,
        req.body.contact_no,
        req.body.first_name,
        req.body.last_name,
        req.body.emp_id,
        req.body.designation,
        req.body.supervisor_name,
        req.body.project_name,
        req.body.default,
        req.body.supervisor_email_id];
        sqldbcon.connection.query("INSERT INTO user_information (email_id, pass_key, contact_no, first_name, last_name, emp_id, designation, supervisor_name, project_name, default_search, supervisor_email) VALUES(?);",[values] ,(err,rows) => {
        if(err){
            console.log()
            // console.log("Before err -----------------");
            // console.log(err.code);
            // console.log("After err ------------------");
           // sqldbcon.connection.end();
           valid_cred = false;
           if(err.code == 'ER_DUP_ENTRY'){
               res.json({
                   success: false,
                   message: 'User already registered !!',
              });
           }
           else{
               message_str = "Registration Cancelled with Error Code " + err.code;
               res.json({
                   success: false,
                   message: message_str
               })
           }
           
        }
        else{
            console.log('Data inserted to DB:\n');
            //console.log("Before err -----------------");
            console.log(rows);
            //console.log("After err ------------------");

            //sqldbcon.connection.end();
            //sqldbcon.connection.release();
            res.json({
                success: true,
                message: 'Welcome New User!',
            });
        }
      });
    
});
module.exports = router;
