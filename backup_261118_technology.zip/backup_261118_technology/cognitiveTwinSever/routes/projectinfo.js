var express = require('express');
var router = express.Router();
var sqldbcon = require('./configdetails/sqldbdetails');

  router.post('/getList/', function(req, res, next) {
      console.log("inside getting project list");
    //var projectId = req.body.projectId;
    sqldbcon.connection.query('SELECT * FROM project_info',(err, resp) => {
        if(err){
            console.log(err);
            res.send(err);
        } else {
            console.log(resp);
            //var record = resp[0];
            res.send(resp);
            //sqldbcon.connection.release();
        }
    })
})
module.exports = router;