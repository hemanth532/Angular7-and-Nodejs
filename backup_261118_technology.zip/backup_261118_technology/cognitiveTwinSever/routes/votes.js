var express = require('express');
var router = express.Router();
var elasticsearchdetails = require('./configdetails/elasticsearchdetails');

function updateLikes(index, type, id){
    return new Promise(function(resolve, reject){
        resolve( elasticsearchdetails.client.update({
            index: index,
            type: type,
            id: id,
            body: {
              script: {
                  inline: "if ( ctx._source.containsKey('likes') ) { ctx._source.likes -= 1 } else { ctx._source.likes = 1 }",
                  lang: "painless",
                  params: {
                      tag: "likes"
                  }
              },
              upsert: {
                likes: 1
              }
            }
          }) 
        );
    });
}

function updateDislike(index, type, id){
    return new Promise(function(resolve, reject){
        resolve( elasticsearchdetails.client.update({
            index: index,
            type: type,
            id: id,
            body: {
                script: { 
                    inline: "if( ctx._source.containsKey('dislikes')) { ctx._source.dislikes += 1 } else { ctx._source.dislikes = 1}",
                    lang: "painless",
                    params: {
                        tag: "dislikes"
                    }
                },
                upsert: {
                    dislikes: 1
                }
            }
        }))
    })
}

router.post('/update/',async function(req, res, err){
    var vote = req.body.vote;
    var questionId = req.body.questionId;
    var project = req.body.project;
    if(vote == 'like'){
        if(project == 'All'){
            var resp1 = await updateLikes('questions_so', 'question', questionId).catch(err => {
                console.log(err);
            });
            var resp2 = await updateLikes('questions_ppms', 'question', questionId).catch(err => {
                console.log(err);
            });
            resp = {
                respDefault: resp1,
                respPPMS: resp2
            }
        }
        if(project == 'Default'){
            var resp = await updateLikes('questions_so', 'question', questionId).catch(err => {
                console.log(err);
            });
        }
        else{
            var resp = await updateLikes('questions_ppms', 'question', questionId).catch(err => {
                console.log(err);
            });
        }
        
    }
    if(vote == 'dislike'){
        if(project == 'All'){
            var resp1 = await updateDislike('questions_so', 'question', questionId).catch(err => {
                console.log(err);
            });
            var resp2 = await updateDislike('questions_ppms', 'question', questionId).catch(err => {
                console.log(err);
            });
            resp = {
                respDefault: resp1,
                respPPMS: resp2
            }
        }
        if(project == 'Default'){
            var resp = await updateDislike('questions_so', 'question', questionId).catch(err => {
                console.log(err);
            });
        }
        else{
            var resp = await updateDislike('questions_ppms', 'question', questionId).catch(err => {
                console.log(err);
            });
        }
    }
    res.send(resp)
});



module.exports = router;