/* starts common code for all file */
var elasticsearch=require('elasticsearch');

var client = new elasticsearch.Client( {
  hosts: [
    'http://13.250.164.25:6333/',
  ]
});
if (!client) {
    client.connect();
}
/* ends  common code for all file */
// 'http://elastic:cloudteam\@123@13.250.164.25:6333/'

module.exports = { client };