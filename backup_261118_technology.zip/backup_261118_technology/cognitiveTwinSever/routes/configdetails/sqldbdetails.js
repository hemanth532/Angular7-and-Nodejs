const mysql = require('mysql');
var application = require('../../public/application.properties');
console.log('application SQl'+JSON.stringify(application.properties.sqldb))
var db_config = {
    host: application.properties.sqldb.host,
    //socketPath : '/tmp/mysql.sock',
    user: application.properties.sqldb.user,
    password: application.properties.sqldb.password,
    //insecureAuth: true,
    database: application.properties.sqldb.database,
    debug: application.properties.sqldb.debug,
    connectionLimit : 100,
    waitForConnections : true,
    queueLimit :0,
    wait_timeout : 28800,
    connect_timeout :10,
  };
  
/*  function handleDisconnect() {
    connection = mysql.createConnection(db_config);
    console.log("connection done with mysql db")
  
    connection.connect(function(err) {            
      if(err) {                         
        console.log('error when connecting to db:', err);
        setTimeout(handleDisconnect, 2000); 
      }                                    
    });                                     
    connection.on('error', function(err) {
      connection.destroy();
      console.log('db error', err);
      if(err.code === 'PROTOCOL_CONNECTION_LOST') {
        handleDisconnect(); 
      } else {  
        handleDisconnect();                             
      }
    });
  }
  
  handleDisconnect(); */

/*var pool = mysql.createPool(db_config);

var connection = pool.getConnection(function(err, connections) {
  if(err){
    console.log("pool connection error");
    throw err;
  }
  else{
    return connections;
  }
}); */

/*pool.getConnection(function(err, connections) {
  if (err) throw err; 
  else{
    connection = connections;
  }
});*/

var connection = mysql.createPool(db_config);
connection.on('connection', function(connection){
  console.log("Connection to db is established !!!");
  connection.on('error', function(err){
    console.log("Mysql error : ",err.code);
  });
  connection.on('close', function(err){
    console.log("Mysql error : ",err.code);
  });
});
  
module.exports = { connection};