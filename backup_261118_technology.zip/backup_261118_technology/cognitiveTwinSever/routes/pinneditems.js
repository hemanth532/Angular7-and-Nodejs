var express = require('express');
var router = express.Router();
var elasticsearchdetails = require('./configdetails/elasticsearchdetails');

var answers = new Array();

router.post('/save/', function(req, res, next) {
    var userId = req.body.userId;
    var title = req.body.title;
    var questionId = req.body.questionId;
    var questionBody = req.body.questionBody;
    var answerId = req.body.answerId;
    var answerBody = req.body.answerBody;
    var isPinned = req.body.isPinned;
    var rating = req.body.rating;
    var id = '_' + Math.random().toString(36).substr(2, 9);
    var query = req.body.query;
    var technology = req.body.technology;
    console.log(questionBody);
    elasticsearchdetails.client.create({
        index: 'pin_results',
        type: 'save_results',
        id: id,
        body: {
            userId: userId,
            title: title,
            questionId: questionId,
            questionBody: questionBody,
            answerId: answerId,
            answerBody: answerBody,
            isPinned: isPinned,
            rating: rating,
            query: query,
            technology:technology
        }
    }, function(err, resp, status){
        if(err){
            console.log(err);
            res.send(err);
        } else {
            console.log(resp)
            res.send(resp);
        }
    });
});

router.post('/get/', function(req, res, next) {
    //var itemId = req.body.itemId;
    var userId = req.body.userId;
    elasticsearchdetails.client.search({
        index: 'pin_results',
        type: 'save_results',
        size: 2000,
        _source: ['title', 'questionBody','answerBody','isPinned','rating','questionId','query','technology'],
        body: {
            query: {
                match: {'userId': userId }
            },
        }
    }, function(err, resp, status){
        if(err){
            res.send(err);
        } else {
            res.send(resp);
        }
    });
});

router.post('/remove/', function(req, res, next) {
    var itemId = req.body.itemId;
    elasticsearchdetails.client.delete({
        index: 'pin_results',
        type: 'save_results',
        id: itemId
    }, function(err, resp, status){
        if(err){
            res.send(err);
        } else {
            res.json({
                "success":resp
            });
        }
    });
});

router.post('/removeAll/', function(req, res, next) {
   
    var itemIds = req.body.itemIds;
    var j = 0;
    var len = itemIds.length;
    for(var i=0;i<itemIds.length;i++){
        var itemId = itemIds[i]._id;
        console.log('itemIds-->'+itemId);
        elasticsearchdetails.client.delete({
            index: 'pin_results',
            type: 'save_results',
            id: itemId
        }, function(err, resp, status){
            if(err){
                res.send(err);
            }
            j++;
            if(j == len){
                var msg = "deleted " + j + " records";
                res.json({
                    "message":msg
                });
            }
        });
    }
})


module.exports = router;