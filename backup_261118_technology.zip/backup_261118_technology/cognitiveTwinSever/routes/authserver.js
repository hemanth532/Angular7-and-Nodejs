var express = require('express');
var router = express.Router();
var sqldbcon = require('./configdetails/sqldbdetails');
var application = require('../public/application.properties');
var jwt    = require('jsonwebtoken');

console.log('application.properties.sqldb.secret'+application.properties.sqldb.secret);


router.post('/create/', function(req, res, next) {
    var username = req.body.username;
    var password = req.body.password;
    sqldbcon.connection.query('SELECT email_id, pass_key,first_name, last_name,supervisor_name,project_name,default_search FROM user_information where email_id = ?',[username], (err,rows) => {
        if(err){
            console.log(err);
            res.send(err);
        }
        else{

            if(rows.length == 0){
                res.json({
                    success: false,
                    message: 'User Not Registered !!!',
                    token: {}
                  });
            }
            if(rows.length){
                console.log('Data received from Db:\n');
                console.log(rows);
                var user = rows[0].email_id;
                var userFname = rows[0].first_name;
                var userLname = rows[0].last_name;
                var pwd = rows[0].pass_key;
                var supervisorName = rows[0].supervisor_name;
                var projectName = rows[0].project_name;
                var defaults = rows[0].default_search;
                console.log(req.body);
                console.log(req.body.username);
                var valid_cred = false;
                if(req.body.username == user && req.body.password == pwd){
                valid_cred = true;
                var payload = {
                    user : req.body.username,
                    cred: valid_cred
                };
        
                var token = jwt.sign(payload, application.properties.sqldb.secret, {
                    expiresIn: 1440 // expires in 24 hours
                  });

                 // sqldbcon.connection.end();
                  res.json({
                    success: true,
                    message: 'User Authorized !!',
                    token: token,
                    userFname: userFname,
                    userLname: userLname,
                    userId: user,
                    projectName: projectName,
                    default: defaults,
                    supervisorName: supervisorName
                  });
            }
            else{
               // sqldbcon.connection.end();
                valid_cred = false;
                res.json({
                    success: false,
                    message: 'Authorization Failed !!',
                    token: {}
                  });
            }
        }
        //sqldbcon.connection.release();
    }
    });
    
});
module.exports = router;