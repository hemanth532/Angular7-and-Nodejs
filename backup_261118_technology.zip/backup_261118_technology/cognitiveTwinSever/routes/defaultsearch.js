var express = require('express');
var router = express.Router();
var elasticsearchdetails = require('./configdetails/elasticsearchdetails');
var Client = require('node-rest-client').Client;
var clientModel = new Client(); 
var application = require('../public/application.properties');

function get_questions(query){
      return new Promise(function(resolve, reject){
          resolve( elasticsearchdetails.client.search({
            index: 'questions_so',
            size: 10,
            type: 'question',
            _source: ['Id', 'Title', 'Body', 'Tags'],
            body: {
              query: {
                match: {'Title': query}
              },
            }
          }) 
          );
      });
  }

function get_pinItems(userId){
  return new Promise(function(resolve, reject){
    resolve( elasticsearchdetails.client.search({
      index: 'pin_results',
      type: 'save_results',
      size: 2000,
      _source: ['title', 'questionBody','answerBody','isPinned','rating','questionId','query','technology'],
      body: {
          query: {
              match: {'userId': userId }
          },
      }
  }) );
  })
}

function get_answer(question_id){
    return new Promise(function(resolve, reject){
        resolve( elasticsearchdetails.client.search({
            index: 'answers_so',
            type: 'answer',
            size: 20,
            _source: ['Body', 'ParentId', 'Id'],
            body: {
              query: {
                match: {
                  'ParentId': question_id
                },
              }
            }
          }) 
        );
    });
}

function get_answer_list(questions_list, answers){
  return new Promise (async function(resolve, reject){
    for(var i = 0; i < questions_list.length; i++) {
      var ans = await get_answer(questions_list[i]._source.Id);
      var ansList = ans.hits.hits;
          if(ansList && ansList.length>0 && ansList[0].hasOwnProperty('_source')){
            answers.push(ansList[0]._source);
          }
    }
    resolve (answers);
  })
}

function get_pinStatus(questions,pinnedResp){
  return new Promise( function(resolve, reject){
    var pinQuesList = pinnedResp.hits.hits;
    var queryQuesList = questions.hits.hits;
    var flag = 0;
    for(var i=0; i<queryQuesList.length; i++){
      var queryQuesId = queryQuesList[i]["_source"]["Id"];
      for(var j=0; j<pinQuesList.length; j++){
        var pinQuesId = pinQuesList[j]["_source"]["questionId"];
        if(queryQuesId == pinQuesId){
          queryQuesList[i]["_source"]["isPinned"]="true";
          flag = 1;
          break;
        }
      }
      if(!flag){
        queryQuesList[i]["_source"]["isPinned"]="false";
      }
      flag = 0;
      var json_unOrder = queryQuesList[i]["_source"];
      var json_order = JSON.parse(JSON.stringify( json_unOrder, ["Tags","Body","Id","Title","isPinned"]));
      queryQuesList[i]["_source"] = json_order;
    }
    questions.hits.hits = queryQuesList;
    resolve(questions); 
  })
}

router.post('/getQuestions/',async function(req, res, next) {
  var query = req.body.query;
  var userId = req.body.query;
  var answers = new Array();
  //var userId = req.body.userId;
  var questions = await get_questions(query);
  var pinnedResp = await get_pinItems(userId);
  var pinnedResults = await get_pinStatus(questions,pinnedResp);
  var questions_list = questions.hits.hits;
  var answers_list = await get_answer_list(questions_list,answers);
  res.json({
    "questions":pinnedResults,
    "answers":answers_list
  });
});

  module.exports = router;