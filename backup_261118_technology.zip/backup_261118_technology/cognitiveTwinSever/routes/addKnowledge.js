var express = require('express');
var router = express.Router();
var elasticsearchdetails = require('./configdetails/elasticsearchdetails');

function addAnswer(index, type, id, body){
    return new Promise(function(resolve, reject){
        resolve( elasticsearchdetails.client.create({
            index: index,
            type: type,
            id: id,
            body: body
        }) 
    )
    });
}

function addQuestion(index, type, id, body){
    return new Promise(function(resolve, reject){
        resolve( elasticsearchdetails.client.create({
            index: index,
            type: type,
            id: id,
            body: body
        }) 
    )
    });
}

router.post('/addQA/',async function(req, res, err){
    var title = req.body.title;
    var tags = req.body.tags;
    var questionBody = req.body.questionBody;
    var questionIndexId = '_' + Math.random().toString(36).substr(2, 9);
    var questionId = Math.floor(Math.random() *  100000000);
    var initLikes = 0;
    var initDislikes = 0;

    var quesObj = {
        Title: title,
        Tags: tags,
        Body: questionBody,
        Id: questionId,
        likes: initLikes,
        dislikes: initDislikes
    }

    var parentId = questionId;
    var answerIndexId = '_' + Math.random().toString(36).substr(2, 9);
    var answerId = Math.floor(Math.random() *  100000000);
    var answerBody = req.body.answerBody;

    var ansObj = {
        ParentId: parentId,
        Id: answerId,
        Body: answerBody,
        likes: initLikes,
        dislikes: initDislikes
    }

    //var project = req.body.project;

    var addQuesSuccess = await addQuestion('questions_ppms', 'question', questionIndexId, quesObj).catch( err => {
        console.log(err);
        res.send(err);
    });
    
    var addAnsSuccess = await addAnswer('answers_ppms', 'answers', answerIndexId, ansObj).catch( err => {
        console.log(err);
        res.send(err);
    });

    res.json({
        "question":addQuesSuccess,
        "answer":addAnsSuccess
    });
});

router.post('/addAnswer/',async function(req, res, next){
    var parentId = req.body.parentId;
    var answerIndexId = '_' + Math.random().toString(36).substr(2, 9);
    var answerId = Math.floor(Math.random() *  100000000);
    var answerBody = req.body.answerBody;
    var initLikes = 0;
    var initDislikes = 0;

    var ansObj = {
        ParentId: parentId,
        Id: answerId,
        Body: answerBody,
        likes: initLikes,
        dislikes: initDislikes
    }

    var addAnsSuccess = await addAnswer('answers_ppms', 'answers', answerIndexId, ansObj).catch(err => {
        res.send(err);
    });

    res.send(addAnsSuccess);
})


module.exports = router;