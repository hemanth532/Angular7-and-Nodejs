var express = require('express');
var router = express.Router();
var elasticsearchdetails = require('./configdetails/elasticsearchdetails');

router.post('/save/', function(req, res, next) {
    var query = req.body.query;
    var technology = req.body.technology;
    var userId = req.body.userId;
    var id = '_' + Math.random().toString(36).substr(2, 9);
    elasticsearchdetails.client.create({
        index: 'users',
        type: 'user',
        id: id,
        body: {
          query: query,
          userId: userId,
          technology: technology,
          timeStamp: new Date()
          //published: new Date().toLocaleString()
        }
    }, function(err, resp, status){
        if(err){
            res.send(err);
        }
        else{
            res.json({
                "response":resp
            });
        }
    });
});

router.post('/get/', function(req, res, next) {
    var userId = req.body.userId;
    elasticsearchdetails.client.search({
        index: 'users',
        size: 2000,
        type: 'user',
        _source: ['query', 'timeStamp','technology'],
        body: {
            query: {
                match: {'userId': userId}
            },
        }
    }, function(err, resp, status){
        if(err){
            res.send(err);
        } else {
            res.send(resp);
        }
    });
})

router.post('/remove/', function(req, res, next) {
    var itemId = req.body.itemId;
    console.log('itemId'+itemId);
    elasticsearchdetails.client.delete({
        index: 'users',
        type: 'user',
        id: itemId
    }, function(err, resp, status){
        if(err){
            res.send(err);
        } else {
            res.json({
                "success":resp
            });
        }
    });
});

router.post('/removeMulti/', function(req, res, next) {
    var itemIds = req.body.itemIds;
    var j = 0;
    var len = itemIds.length;
    for(var i=0;i<itemIds.length;i++){
        var itemId = itemIds[i]._id;
        elasticsearchdetails.client.delete({
            index: 'users',
            type: 'user',
            id: itemId
        }, function(err, resp, status){
            if(err){
                res.send(err);
            }
            j++;
            if(j == len){
                var msg = "deleted " + j + " records";
                res.json({
                    "message":msg
                });
            }
        });
    }
});
module.exports = router;
