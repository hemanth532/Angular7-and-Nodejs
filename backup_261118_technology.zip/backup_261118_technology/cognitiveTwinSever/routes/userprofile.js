
var express = require('express');
var router = express.Router();
var sqldbcon = require('./configdetails/sqldbdetails');

  router.post('/get/', function(req, res, next) {
    var userId = req.body.userId;
    sqldbcon.connection.query('SELECT email_id, contact_no, first_name, last_name, emp_id, designation, supervisor_name, project_name FROM user_information where email_id = ?',[userId],(err, resp) => {
        if(err){
            console.log(err);
            res.send(err);
        } else {
            console.log(resp);
            var record = resp[0];
            //sqldbcon.connection.release();
            res.send(record);
        }
    })
})
module.exports = router;