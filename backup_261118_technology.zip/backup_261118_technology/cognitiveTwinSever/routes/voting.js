var MongoClient = require('mongodb').MongoClient;
var express = require('express');
var elasticsearchdetails = require('./configdetails/elasticsearchdetails');
var router = express.Router();
var application = require('../public/application.properties');

function connectMongo(){
    return new Promise(function(resolve, reject){
        resolve( MongoClient.connect("mongodb://localhost:27017"));
    })
}

function incrementLikes(index, type, id){
    return new Promise(function(resolve, reject){
        resolve( elasticsearchdetails.client.update({
            index: index,
            type: type,
            id: id,
            body: {
              script: {
                  inline: "if ( ctx._source.containsKey('likes') ) { ctx._source.likes += 1 } else { ctx._source.likes = 1 }",
                  lang: "painless",
                  params: {
                      tag: "likes"
                  }
              },
              upsert: {
                likes: 1
              }
            }
          }) 
        );
    });
}

function decrementLikes(index, type, id){
    return new Promise(function(resolve, reject){
        resolve( elasticsearchdetails.client.update({
            index: index,
            type: type,
            id: id,
            body: {
              script: {
                  inline: "if ( ctx._source.containsKey('likes') ) { ctx._source.likes -= 1 } else { ctx._source.likes = 0 }",
                  lang: "painless",
                  params: {
                      tag: "likes"
                  }
              },
              upsert: {
                likes: 1
              }
            }
          }) 
        );
    });
}

function incrementDislike(index, type, id){
    return new Promise(function(resolve, reject){
        resolve( elasticsearchdetails.client.update({
            index: index,
            type: type,
            id: id,
            body: {
                script: { 
                    inline: "if( ctx._source.containsKey('dislikes')) { ctx._source.dislikes += 1 } else { ctx._source.dislikes = 1}",
                    lang: "painless",
                    params: {
                        tag: "dislikes"
                    }
                },
                upsert: {
                    dislikes: 1
                }
            }
        }))
    })
}

function decrementDislike(index, type, id){
    return new Promise(function(resolve, reject){
        resolve( elasticsearchdetails.client.update({
            index: index,
            type: type,
            id: id,
            body: {
                script: { 
                    inline: "if( ctx._source.containsKey('dislikes')) { ctx._source.dislikes -= 1 } else { ctx._source.dislikes = 0}",
                    lang: "painless",
                    params: {
                        tag: "dislikes"
                    }
                },
                upsert: {
                    dislikes: 1
                }
            }
        }))
    })
}

function updateVotes_mongo(mongo_obj, vote){
    return new Promise(async function(resolve, reject){
        var dbConnection = await connectMongo().catch(err => {
            console.log(err);
            res.send(err);
        });
    
        var db = dbConnection.db('usersDb');
    
        var collection = db.collection('usersVotes');
    
        resolve(collection.updateMany(mongo_obj, {$set: {vote: vote}}));
    })
}

function removeVotes_mongo(mongo_obj){
    return new Promise(async function(resolve, reject){
        var dbConnection = await connectMongo().catch(err => {
            console.log(err);
            res.send(err);
        });
        var db = dbConnection.db('usersDb');
        var collection = db.collection('usersVotes');
        resolve(collection.remove(mongo_obj));
    })
}

function addVotes_mongo(mongo_obj){
    return new Promise(async function(resolve, reject){
        var dbConnection = await connectMongo().catch(err => {
            console.log(err);
            res.send(err);
        });
    
        var db = dbConnection.db('usersDb');
    
        var collection = db.collection('usersVotes');
    
        resolve(collection.insert(mongo_obj).catch(err => {
            console.log(err);
        }) );
    })
}

function search_mongo(userId, questionId){
    return new Promise(async function(resolve, reject){
        var dbConnection = await connectMongo().catch(err => {
            console.log(err);
            res.send(err);
        });
        var db = dbConnection.db('usersDb');
        var collection = db.collection('usersVotes');
        var items = collection.find({$and:[{'userId':userId},{'questionId':questionId}]}).toArray();
        resolve(items);
    });
}

function ifExist(index, type, questionId){
    return new Promise(function(resolve, reject){
        resolve();
    })
}

function getCount(index, type, questionId){
    return new Promise(function(resolve, reject){
        resolve();
    })
}

function search_index(index, type, source, match){
    return new Promise(function(resolve, reject){
        resolve( elasticsearchdetails.client.search({
            index: index,
            type: type,
            size: 10,
            _source: source,
            body: {
              query: {
                match: match,
              }
            }
          }) 
        );
    });
}

router.post('/update/',async function(req, res, next){
    var documentId = req.body.documentId;
    var questionId = req.body.questionId;
    var userId = req.body.userId;
    var vote = req.body.vote;
    var final_mongo_resp;
    var final_elastic_resp;
    var index;
    var type = "question";
    questionId = questionId.toString();

    var search_ppms = await search_index("questions_ppms", "question", ['Id', 'Body', 'Tags', 'likes', 'dislikes'], {'Id': questionId}).catch(err => {
        console.log(err);
    });

    var search_so = await search_index("questions_so", "question", ['Id', 'Title' ,'Body', 'Tags', 'likes', 'dislikes'], {'Id': questionId}).catch(err => {
        console.log(err);
    });

    if(search_ppms.hits.total){
        index = "questions_ppms";
        console.log("present in ppms");
    }
    if(search_so.hits.total){
        index = "questions_so";
        console.log("present in SO");
    }

    var mongo_resp = await search_mongo(userId, questionId).catch(err => {
        console.log(err);
    });

    if(!mongo_resp.length){
        if(vote=="like"){
            final_elastic_resp = await incrementLikes(index, type, documentId).catch(err => {
                console.log(err);
            });
            console.log(final_elastic_resp);
        }
        if(vote=="dislike"){
            final_elastic_resp = await incrementDislike(index, type, documentId).catch(err => {
                console.log(err);
            });
            console.log(final_elastic_resp);
        }
        final_mongo_resp = await addVotes_mongo({"questionId":questionId,"userId":userId,"vote":vote}).catch(err => {
            console.log(err);
        });
        console.log(final_mongo_resp);
    }
    else if(mongo_resp && mongo_resp.length > 0 && vote == "noVote"){
        var mongo_vote = mongo_resp[0]["vote"];
        if(mongo_vote == "like"){
            final_elastic_resp = await decrementLikes(index, type, documentId).catch(err => {
                console.log(err);
            });
        }
        if(mongo_vote == "dislike"){
            final_elastic_resp = await decrementDislike(index, type, documentId).catch(err => {
                console.log(err);
            })
        }
        final_mongo_resp = await removeVotes_mongo({"questionId":questionId,"userId":userId}).catch(err => {
            console.log(err);
        });
    }
    else if(mongo_resp && mongo_resp.length > 0 && vote == "like"){
        var mongo_vote = mongo_resp[0]["vote"];
        if(mongo_vote == "dislike"){
            final_elastic_resp = await incrementLikes(index, type, documentId).catch(err => {
                console.log(err);
            });
            final_elastic_resp = await decrementDislike(index, type, documentId).catch(err => {
                console.log(err);
            });
            final_mongo_resp = await updateVotes_mongo({"questionId":questionId,"userId":userId},vote).catch(err => {
                console.log(err);
            });
        }
    }
    else if(mongo_resp && mongo_resp.length > 0 && vote == "dislike"){
        var mongo_vote = mongo_resp[0]["vote"];
        if(mongo_vote == "like"){
            final_elastic_resp = await incrementDislike(index, type, documentId).catch(err => {
                console.log(err);
            });
            final_elastic_resp = await decrementLikes(index, type, documentId).catch(err => {
                console.log(err);
            });
            final_mongo_resp = await updateVotes_mongo({"questionId":questionId,"userId":userId},vote).catch(err => {
                console.log(err);
            });
        }
    }
    else{
        final_elastic_resp = "nothing is done in ES";
        final_mongo_resp = "nothing is done in MDb";
    }

    res.json({
        "elastic_resp":final_elastic_resp,
        "mongo_resp":final_mongo_resp
    });

});

module.exports = router;