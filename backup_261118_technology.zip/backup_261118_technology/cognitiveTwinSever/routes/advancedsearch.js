var express = require('express');
var router = express.Router();
var elasticsearchdetails = require('./configdetails/elasticsearchdetails');


router.post('/Add/', function(req, res, next) {
    var query = req.body.query;
    var technology = req.body.technology;
    var userId = req.body.userId;
    var searchName = req.body.searchName;
    var id = '_' + Math.random().toString(36).substr(2, 9);
    console.log(req);
    elasticsearchdetails.client.create({
        index: 'search_category',
        type: 'personalisedSearch',
        id: id,
        body: {
          query: query,
          userId: userId,
          technology: technology,
          searchName: searchName
        }
    },function (error, resp,status) {
        if (error){
          console.log("search error: "+error)
          res.send(error);
        }
        else {
            res.json({
                //'ret':resp
                'ret':true
            });
        }
      });
});

router.post('/Get/', function(req, res, next) {
    var userId = req.body.userId;
    console.log(req);
    elasticsearchdetails.client.search({
        index: 'search_category',
        size: 100,
        type: 'personalisedSearch',
        _source: ['query', 'technology', 'searchName'],
        body: {
          query: {
            match: {'userId': userId}
            },
        }
    },function (error, resp,status) {
        if (error){
          console.log("search error: "+error)
          res.send(error);
        }
        else {
            /*res.json({
                'ret':resp
            });*/
            res.send({'ret':resp});
        }
      });
});

router.post('/Update/', function(req, res, next) {
    var searchId = req.body.searchId;
    var technology = req.body.technology;
    var query = req.body.query;
    console.log(req);
    elasticsearchdetails.client.update({
        index: 'search_category',
        type: 'personalisedSearch',
        id: searchId,
        body: {
          doc : { 
              technology : technology,
              query : query
            }
        }
    },function (error, resp,status) {
        if (error){
          console.log("search error: "+error)
          res.send(error);
        }
        else {
            
            res.json({
                'ret':true
            });
        }
      });
});

router.post('/Remove/', function(req, res, next) {
    var itemId = req.body.itemId;
    elasticsearchdetails.client.delete({
        index: 'search_category',
        type: 'personalisedSearch',
        id: itemId
    }, function(err, resp, status){
        if(err){
            console.log(err)
            res.send(err);
        }
        else{
            res.json({
                "response":resp
            });
        }
    });
});
module.exports = router;