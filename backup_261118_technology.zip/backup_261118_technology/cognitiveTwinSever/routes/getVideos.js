var express = require('express');
var router = express.Router();
var elasticsearchdetails = require('./configdetails/elasticsearchdetails');
var Client = require('node-rest-client').Client;

function getVideoLinks(index, type, source, match){
    return new Promise(function(resolve, reject){
        resolve( elasticsearchdetails.client.search({
            index: index,
            size: 10,
            type: type,
            _source: source,
            body: {
                query: {
                    match: match
                },
            }
        }) 
    );
})
}

router.post('/get/', async function(req, res, next){
    var query = req.body.query;
    var userId = req.body.userId;
    var project = req.body.project;
    if(project == 'Default'){
        var videoList = await getVideoLinks("skillport_videos", "video", ['Module', 'Topic', 'Duration', 'Summary', 'Link'], {'Topic':query}).catch(err => {
            res.send(err);
        });
        res.json({
            "videoList":videoList.hits.hits
        });
    }
    else{
        res.json({
            "videoList":[]
        });
    }
})

module.exports = router;