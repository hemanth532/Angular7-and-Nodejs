var express = require('express');
var router = express.Router();
var elasticsearchdetails = require('./configdetails/elasticsearchdetails');
var Client = require('node-rest-client').Client;
var clientModel = new Client(); 
var application = require('../public/application.properties');
var ppmsObj = require('./ppms');
var defaultObj = require('./defaultsearch');
var MongoClient = require('mongodb').MongoClient;

function connectMongo(){
  return new Promise(function(resolve, reject){
      resolve( MongoClient.connect("mongodb://localhost:27017"));
  })
}

function getVideoLinks(index, type, source, match){
  return new Promise(function(resolve, reject){
    resolve( elasticsearchdetails.client.search({
      index: index,
      size: 10,
      type: type,
      _source: source,
      body: {
        query: {
          match: match
        },
      }
    }) 
    );
  })
}

function getVotes(emailId){
  return new Promise(async function(resolve, reject){
    var userId = emailId;
    var dbConnection = await connectMongo().catch(err => {
      console.log(err);
      res.send(err);
    });
    var db = dbConnection.db('usersDb');
    var collection = db.collection('usersVotes');
    collection.find({'userId':userId}).toArray(function(err, items){
      if(err){
        res.send(err);
      }
      resolve(items);
    });
  });
}

function compareVotes(questionResp, userId){
  return new Promise(async function(resolve, reject){
    var questionList = questionResp.hits.hits;
    var questionVotes = await getVotes(userId).catch(err => {
      throw err;
    });
    var flag = 0;
    for(var i=0; i < questionList.length; i++){
      var queryQuesId = questionList[i]["_source"]["Id"];
      for(var j=0; j < questionVotes.length; j++){
        var userVote = questionVotes[j]["vote"];
        var questionId = questionVotes[j]["questionId"];
        if(queryQuesId == questionId){
          questionList[i]["_source"]["vote"]=userVote;
          flag = 1;
          break;
        }
      }
      if(!flag){
        questionList[i]["_source"]["vote"]="noVote";
      }
      flag = 0;
    }
    questionResp.hits.hits = questionList;
    resolve(questionResp);
  })
}

function get_questions(index, type, source, match){
    return new Promise(function(resolve, reject){
        resolve( elasticsearchdetails.client.search({
          index: index,
          size: 10,
          type: type,
          _source: source,
          body: {
            query: {
              match: match
            },
          }
        }) 
        );
    });
}

function get_pinItems(userId){
    return new Promise(function(resolve, reject){
      resolve( elasticsearchdetails.client.search({
        index: 'pin_results',
        type: 'save_results',
        size: 2000,
        _source: ['title', 'questionBody','answerBody','isPinned','rating','questionId','query','technology'],
        body: {
            query: {
                match: {'userId': userId }
            },
        }
    }) );
    })
  }

  function get_answer(index, type, source, match){
    return new Promise(function(resolve, reject){
        resolve( elasticsearchdetails.client.search({
            index: index,
            type: type,
            size: 10,
            _source: source,
            body: {
              query: {
                match: match,
              }
            }
          }) 
        );
    });
}

function get_answer_list_ppms(questions_list, answers){
    return new Promise (async function(resolve, reject){
      for(var i = 0; i < questions_list.length; i++) {
        var ans = await get_answer("answers_ppms","answers",['Body', 'ParentId', 'Id'],{'ParentId': questions_list[i]._source.Id });
        var ansList = ans.hits.hits;
            if(ansList && ansList.length>0 && ansList[0].hasOwnProperty('_source')){
              answers.push(ansList[0]._source);
            }
      }
      resolve (answers);
    })
  }

  function get_answer_list_so(questions_list, answers){
    return new Promise (async function(resolve, reject){
      for(var i = 0; i < questions_list.length; i++) {
        var ans = await get_answer("answers_so","answer",['Body', 'ParentId', 'Id'],{'ParentId': questions_list[i]._source.Id });
        var ansList = ans.hits.hits;
            if(ansList && ansList.length>0 && ansList[0].hasOwnProperty('_source')){
              answers.push(ansList[0]._source);
            }
      }
      resolve (answers);
    })
  }

  function get_pinStatus(questions,pinnedResp){
    return new Promise( function(resolve, reject){
      var pinQuesList = pinnedResp.hits.hits;
      var queryQuesList = questions.hits.hits;
      var flag = 0;
      for(var i=0; i<queryQuesList.length; i++){
        var queryQuesId = queryQuesList[i]["_source"]["Id"];
        for(var j=0; j<pinQuesList.length; j++){
          var pinQuesId = pinQuesList[j]["_source"]["questionId"];
          if(queryQuesId == pinQuesId){
            queryQuesList[i]["_source"]["isPinned"]="true";
            flag = 1;
            break;
          }
        }
        if(!flag){
          queryQuesList[i]["_source"]["isPinned"]="false";
        }
        flag = 0;
        var json_unOrder = queryQuesList[i]["_source"];
        var json_order = JSON.parse(JSON.stringify( json_unOrder, ["Tags","Body","Id","Title","likes","dislikes","isPinned"]));
        queryQuesList[i]["_source"] = json_order;
      }
      questions.hits.hits = queryQuesList;
      resolve(questions); 
    })
  }
  


router.post('/get/',async function(req, res, next) {
    var query = req.body.query;
    var userId = req.body.userId;
    var project = req.body.project;
    var answers = new Array();

    if(project=="All"){
      console.log("inside combine search");
      var questions = await get_questions("questions_ppms", "question", ['Id', 'Body', 'Tags', 'likes', 'dislikes'], {'Body': query}).catch(err => {
        res.send(err);
      }); //get_questions(query);
      var pinnedResp = await get_pinItems(userId).catch(err => {
        res.send(err);
      }); //get_pinItems(userId);
      var pinnedResults_ppms = await get_pinStatus(questions,pinnedResp).catch(err => {
        res.send(err);
      }); //get_pinStatus(questions,pinnedResp);

      var votesResult_ppms = await compareVotes(pinnedResults_ppms, userId).catch(err => {
        res.send(err);
      })

      console.log(JSON.stringify(votesResult_ppms));

      var questions_list = questions.hits.hits;
      var answers_list_ppms = await get_answer_list_ppms(questions_list,answers).catch(err => {
        res.send(err);
      });

      var questions = await get_questions("questions_so", "question", ['Id', 'Title' ,'Body', 'Tags', 'likes', 'dislikes'], {'Title': query}).catch(err => {
        res.send(err);
      });
      var pinnedResp = await get_pinItems(userId).catch(err => {
        res.send(err);
      });
      var pinnedResults_so = await get_pinStatus(questions,pinnedResp).catch(err => {
        res.send(err);
      });

      var votesResult_so = await compareVotes(pinnedResults_so, userId).catch(err => {
        res.send(err);
      });

      console.log(JSON.stringify(votesResult_so))

      var questions_list = questions.hits.hits;
      var answers_list_so = await get_answer_list_so(questions_list,answers).catch(err => {
        res.send(err);
      });

      var questions_ppms = votesResult_ppms.hits.hits;
      var questions_so = votesResult_so.hits.hits;

      var questions_list = questions_so.concat(questions_ppms);

      var answers_list = answers_list_so.concat(answers_list_ppms); 

      res.json({
          "questions":questions_list,
          "answers":answers_list,
          "videoList":[]
      })
  }
  else if(project=="Default"){
        var questions = await get_questions("questions_so", "question", ['Id', 'Title' ,'Body', 'Tags', 'likes', 'dislikes'], {'Title': query}).catch(err => {
          res.send(err);
        });
        var pinnedResp = await get_pinItems(userId).catch(err => {
          res.send(err);
        });
        var pinnedResults = await get_pinStatus(questions,pinnedResp).catch(err => {
          res.send(err);
        });

        var votesResult_so = await compareVotes(pinnedResults, userId).catch( err => {
          res.send(err);
        })
        var questions_list = questions.hits.hits;
        var answers_list = await get_answer_list_so(questions_list,answers).catch(err => {
          res.send(err);
        });

        var videoList = await getVideoLinks("skillport_videos", "video", ['Module', 'Topic', 'Duration', 'Summary', 'Link'], {'Topic':query}).catch(err => {
          res.send(err);
        });

        var questions_list = votesResult_so.hits.hits;
        res.json({
            "questions":questions_list,
            "answers":answers_list,
            "videoList":videoList.hits.hits
          });
    }
    
    else{
      var questions = await get_questions("questions_ppms", "question", ['Id', 'Body', 'Tags', 'likes', 'dislikes'], {'Body': query}).catch(err => {
        console.log(err);
        res.send(err);
      }) //get_questions(query);
      var pinnedResp = await get_pinItems(userId).catch(err => {
        res.send(err);
      }); //get_pinItems(userId);
      var pinnedResults = await get_pinStatus(questions,pinnedResp).catch(err => {
        res.send(err);
      }); //get_pinStatus(questions,pinnedResp);

      var votesResult_ppms = await compareVotes(pinnedResults, userId).catch(err => {
        res.send(err);
      })
      var questions_list = questions.hits.hits;
      var answers_list = await get_answer_list_ppms(questions_list,answers).catch(err => {
        res.send(err);
      });  //get_answer_list(questions_list,answers);
      //var response = ppmsObj.getPPMSresults(query, userId);
      var questions_list = votesResult_ppms.hits.hits;
      console.log('questions_list'+questions_list)
      res.json({
          "questions":questions_list,
          "answers":answers_list,
          "videoList":[]
        });
        //res.send(response);
      }
    //var userId = req.body.userId;
  });


module.exports = router;