var MongoClient = require('mongodb').MongoClient;
var express = require('express');
var router = express.Router();

/* // Connect to the db
MongoClient.connect("mongodb://localhost:27017/MyDb", function (err, db) {
   
     if(err) throw err;

     //Write databse Insert/Update/Query code here..
                
});*/

function connectMongo(){
    return new Promise(function(resolve, reject){
        resolve( MongoClient.connect("mongodb://localhost:27017"));
    })
}

router.post('/connect/',async function(req, res, err){
    var dbConnection = await connectMongo().catch(err => {
        console.log(err);
    });

    if(dbConnection){
        res.json({
            'message':'connection to mongoDb is made'
        });
    }
});

router.post('/add/', async function(req, res, err){

    var vote = req.body.vote;
    var userId = req.body.userId;
    var questionId = req.body.questionId;

    var jsonObj = req.body;

    var dbConnection = await connectMongo().catch(err => {
        console.log(err);
        res.send(err);
    });

    var db = dbConnection.db('usersDb');

    var collection = db.collection('usersVotes');

    collection.insert(jsonObj).catch(err => {
        console.log(err);
    });

    res.json({
        'message':'successfully inserted record'
    });

});

router.post('/update/',async function(req, res, err){
    var vote = req.body.vote;
    var userId = req.body.userId;
    var questionId = req.body.questionId;

    var myQuery = {
        'userId':userId,
        'questionId':questionId
    }

    var dbConnection = await connectMongo().catch(err => {
        console.log(err);
        res.send(err);
    });

    var db = dbConnection.db('usersDb');

    var collection = db.collection('usersVotes');

    collection.updateMany(myQuery, {$set: {vote: vote}}, function(err, resp){
        if(err){
            res.send(err);
        }
        res.send(resp);
    });

})

router.post('/get/',async function(req, res, err){

    var userId = req.body.userId;

    var dbConnection = await connectMongo().catch(err => {
        console.log(err);
        res.send(err);
    });

    var db = dbConnection.db('usersDb');

    var collection = db.collection('usersVotes');

    collection.find({'userId':userId}).toArray(function(err, items){
        if(err){
            res.send(err);
        }
        res.send(items);
    });

});

router.post('/remove/',async function(req, res, err){
    var userId = req.body.userId;
    var questionId = req.body.questionId;

    var queryObj = req.body;

    var dbConnection = await connectMongo().catch(err => {
        console.log(err);
        res.send(err);
    });

    var db = dbConnection.db('usersDb');

    var collection = db.collection('usersVotes');

    collection.remove(queryObj, function(err, resp){
        if(err){
            res.send(err);
        }
        res.send(resp);
    });

});

router.post('/testAdd/', async function(req, res, err){
});

module.exports = router;