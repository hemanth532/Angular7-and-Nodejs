var express = require('express');
var router = express.Router();
/*db connection and collection creation*/

//var MongoClient = require('mongodb').MongoClient;
//var url = "mongodb://localhost:27017/";



/* GET home page. */
router.get('/', function(req, res, next) {
  res.send('Welcome to cognitve twin server');
  /*MongoClient.connect(url, function(err, db) {
    if (err) throw err;
    var dbo = db.db("mydb");
    //var myobj = { name: "Company Inc", address: "Highway 37" };
    var sort = { address: 1 };
    dbo.collection("customers").find().sort(sort).toArray(function(err, result) {
      if (err) throw err;
      res.send(result)
      console.log(result);
      db.close();
    });
  });*/
  
});

module.exports = router;
