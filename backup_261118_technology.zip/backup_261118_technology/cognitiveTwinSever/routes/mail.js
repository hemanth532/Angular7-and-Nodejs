var express = require('express');
var router = express.Router();
var Client = require('node-rest-client').Client;
var client = new Client();
//var nodemailer = require('nodemailer');
var application = require('../public/application.properties');
console.log('application'+JSON.stringify(application.properties.mail));

/*router.post('/', function(req, res, next) {
    console.log('hiiiiii');
    var question = req.body.QuestionDetails.Body;
    var answer = req.body.ansArray;
    console.log('question'+question);
    console.log('answer'+answer);
    var mailId = req.body.mailId;
    var transporter = nodemailer.createTransport({
        service: application.properties.mail.service,
        host: application.properties.mail.host,
        port: application.properties.mail.port,
        auth: {
          user: application.properties.mail.userName,
          pass: application.properties.mail.passWord
        }
      });

      var mailOptions = {
        from: application.properties.mail.fromMail,
        to: mailId,
        subject: application.properties.mail.subject,
        html:  '<strong> Q : ' + question + '</strong> <br> <strong>A : </strong> ' + answer 
      };
      
      transporter.sendMail(mailOptions, function(error, info){
        if (error) {
          console.log('error'+error);
          res.send(error);
        } else {
          console.log('Email sent: ' + info.response);
          res.json({
            //'ret':resp
            'ret':true
        });
        }
      });
});*/
router.post('/', function(req, res, next) {
  var question = req.body.QuestionDetails.Body;
  var answer = req.body.ansArray;
  var mailId = req.body.mailId;
  var mailIdCc = req.body.mailIdCc;
  var userName = req.body.userName;
  var userNameMe = req.body.userNameMe;
  var mailBody = application.properties.mail.body.greet + userName + application.properties.mail.body.message + userNameMe + application.properties.mail.body.questionElement + question + application.properties.mail.body.answerElement + answer+ application.properties.mail.body.messageEnd;
var args = {
    data: {
  "password": application.properties.mail.passWord,
  "fromAddress": application.properties.mail.fromMail,
  "toAddress": mailId,
  "msgSubject":  application.properties.mail.subject,
  "msgBody": mailBody,
  "ccAddress": mailIdCc,
}, 
headers: { "Content-Type": "application/json" }
};
 
client.post(application.properties.mail.mailurl, args, function (data, response) { 
    // parsed response body as js object
    console.log(data);
    // raw response
    console.log(response);
    //res.send(JSON.stringify(response));
    res.json({
      success: true,
      message: 'Success'
    });
});

});
module.exports = router;