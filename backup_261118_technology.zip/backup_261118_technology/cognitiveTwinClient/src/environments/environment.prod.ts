export const environment = {
  production: true,
  apiUrl: "my-server:8080/"
};
