import '../polyfills';
import {AppRoutingModule, routingComponents} from './app-routing.module';
import {HttpClientModule} from '@angular/common/http';
import {BrowserModule} from '@angular/platform-browser';
import {NgModule} from '@angular/core';
import {LoginService} from './services/login/login.service';
import {ElacticSearchService} from './services/elastic-search/elactic-search.service';
import {AppComponent} from './app.component';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {HttpModule} from '@angular/http';
import { LoadingModule } from 'ngx-loading';
import {AuthGuard} from './services/route-gaurds/auth.guard';
import {LayoutModule} from './layout/layout.module';
import {SharedModule} from './shared/shared.module';
import {SidenavComponent} from './search-result/sidenav/sidenav.component';
import {ResultComponent} from './search-result/result/result.component';
import {ResultHeaderComponent} from './search-result/result-header/result-header.component';
import {CongitiveCommonModule} from './common/common.module';
import { SignupComponent } from './signup/signup.component';
import { DefaultSearchComponent } from './search/default-search/default-search.component';
import { SignUpService } from './services/signup/signup.service'
import { AdvancedSearchService } from './services/advanced-search/advanced-search-service'
import { CommonService } from './shared/services/common-service';
import { RefinedSearchService } from './services/refined-search/refined-search-service';
import { UndermaintanceComponent } from './undermaintance/undermaintance.component';
import { MailService } from './services/mail/mail-service';
import { PinResultService } from './services/pin-result/pin-result-service';
import { SearchHistoryService } from './services/search-history/search-history-service';
import { ProfileService } from './services/profile/profile.service'
import { TechnologiesService } from './services/technologies/technologies.service'
import { CookieService } from 'angular2-cookie/services/cookies.service';
import { DialogpopupComponent } from './dialogpopup/dialogpopup.component'
import { AddKnowledgeService } from './services/add-knowledge/add-knowledge-service'
import { ProjectDetailsService } from './services/project-details/project-details-service'
import { AddAnswerService} from './services/add-answer/addanswer.service'
import { LikesDislikesService } from './services/likesNdislikes/likes-dislikes.service'
import {JetAirwaysService} from './services/jetairways/jetairways-service'

@NgModule({
  exports: [],
  declarations: [
    AppComponent,
    routingComponents,
    UndermaintanceComponent,
    DialogpopupComponent,
  ],
  entryComponents: [
    DialogpopupComponent
],
  imports: [
    AppRoutingModule,
    BrowserModule,
    BrowserAnimationsModule,
    FormsModule,
    LayoutModule,
    CongitiveCommonModule,
    HttpModule,
    HttpClientModule,
    ReactiveFormsModule,
    LoadingModule,
    SharedModule.forRoot(),

  ],
  providers: [LoginService, AuthGuard, ElacticSearchService,SignUpService,AdvancedSearchService,
    CommonService,RefinedSearchService,MailService,PinResultService,SearchHistoryService,ProfileService,
    TechnologiesService,CookieService,AddKnowledgeService,ProjectDetailsService,AddAnswerService,LikesDislikesService,JetAirwaysService],
  bootstrap: [AppComponent]
})
export class AppModule {
}
