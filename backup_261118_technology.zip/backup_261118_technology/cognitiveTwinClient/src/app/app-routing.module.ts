import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {Routes, RouterModule} from '@angular/router';
import {LoginComponent} from './login/login.component';

import {SearchResultComponent} from './search-result/search-result.component';
import {AuthGuard} from './services/route-gaurds/auth.guard';


import {SignupComponent} from './signup/signup.component';

import { UndermaintanceComponent } from './undermaintance/undermaintance.component'


const routes: Routes = [
  {path: '', component: LoginComponent},
  {path: 'login', component: LoginComponent},
  {path: 'signup', component: SignupComponent},
  {path: 'undermaintance', component: UndermaintanceComponent},
  {
    path: 'search',
    //component: SearchComponent,
    loadChildren: './search/search.module#SearchModule', canActivate: [AuthGuard]
    //  canActivate: [AuthGuard]
  },
  {
    path: 'search-result/:SearchQuery/:techoologies/:pageName/:projectName',
    loadChildren: './search-result/search-result.module#SearchResultModule', canActivate: [AuthGuard]
    //  canActivate: [AuthGuard]
  },
  {
    path: 'search-result/:pageName',
    loadChildren: './search-result/search-result.module#SearchResultModule', canActivate: [AuthGuard]
    //  canActivate: [AuthGuard]
  },
  {path: '**', component: LoginComponent}
];

@NgModule({
  imports: [
    CommonModule,
    RouterModule.forRoot(routes,{useHash: true})
  ],
  exports: [RouterModule],
  declarations: []
})
export class AppRoutingModule {
}

export const routingComponents = [LoginComponent, SignupComponent];
