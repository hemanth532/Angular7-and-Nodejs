import {Injectable} from "@angular/core";
import {HttpClient} from "@angular/common/http";
import "rxjs/add/operator/map";
import {contentHeaders} from "../headers/auth-headers";
import { environment } from '../../../environments/environment';

@Injectable()
export class SignUpService {
 
  constructor(private http: HttpClient) {}
  basePath: string = environment.apiUrl;
  signup(NewUserDetails) {
    console.log('NewUserDetails'+JSON.stringify(NewUserDetails));
    let url = this.basePath+"createaccount/user/registration/";
    return this.http.post(url, NewUserDetails, {headers: contentHeaders}).map(data => {
      return data
    }, err => {
      return null;
    });
  }

}
