import {Injectable} from "@angular/core";
import {HttpClient} from "@angular/common/http";
import "rxjs/add/operator/map";
import {contentHeaders} from "../headers/auth-headers";
import { environment } from '../../../environments/environment';

@Injectable()
export class ProjectDetailsService {

  constructor(private http: HttpClient) {}

  basePath: string = environment.apiUrl;

  getProjectDetails() {
    let url = this.basePath+"projectinfo/getList/";
    return this.http.post(url,{headers: contentHeaders}).map(data => {
      return data
    }, err => {
      return null;
    });
  }
}
