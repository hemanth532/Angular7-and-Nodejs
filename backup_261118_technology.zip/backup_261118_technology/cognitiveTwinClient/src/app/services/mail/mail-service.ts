import {Injectable} from "@angular/core";
import {HttpClient,} from "@angular/common/http";
import {RequestOptions,Headers,RequestMethod} from "@angular/http";
import "rxjs/add/operator/map";
import {contentHeaders} from "../headers/auth-headers";
import { environment } from '../../../environments/environment';

@Injectable()
export class MailService {
 
  constructor(private http: HttpClient) {}
  basePath: string = environment.apiUrl;
  sendMail(question,ansArray,mailId,mailIdCc,userName,userNameMe) {
    let mailobj = {'QuestionDetails':question._source,'ansArray':ansArray,'mailId':mailId,
    'mailIdCc':mailIdCc,'userName':userName,'userNameMe':userNameMe};
    console.log('QuestionDetails'+JSON.stringify(mailobj));
    let url = this.basePath+"mail/";
    //let url = "http://40.76.79.48:8080/sendmailrequest";
    /*var mailDetails =   {
      "password": "nextlabs@2018",
      "fromAddress": "cognitive.twin@mphasis.com",
      "toAddress": mailobj.mailId,
      "msgSubject": "Cognitive Twin",
      "msgBody": mailobj.QuestionDetails.Body,
      "ccAddress":  mailobj.mailId
    };*/
   /* var mailDetails = {
      "password": "nextlabs@2018",
      "fromAddress": "cognitive.twin@mphasis.com",
      "toAddress": "Hemanth.Gode@mphasis.com",
      "msgSubject": "demo",
      "msgBody": "hello sir",
      "ccAddress": "sridhar.c@mphasis.com"
    };*/
    
    //let headers = new Headers({'Content-Type':'application/json'});
    //let options:any = new RequestOptions({headers : headers });
    /*let headers = new Headers({'Accept': 'application/json',
    'Content-type': 'application/json; charset=utf-8'});
    headers.append('Access-Control-Allow-Headers', 'Content-Type');
    headers.append('Access-Control-Allow-Methods', 'POST');
    headers.append('Access-Control-Allow-Origin', '*');
    let options:any = new RequestOptions( {headers: headers });*/
    
    return this.http.post(url, mailobj, {headers: contentHeaders}).map(data => {
      return data
    }, err => {
      return null;
    });
  }
}
