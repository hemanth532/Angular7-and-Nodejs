import {Injectable} from "@angular/core";
import {HttpClient} from "@angular/common/http";
import "rxjs/add/operator/map";
import {contentHeaders} from "../headers/auth-headers";
import { environment } from '../../../environments/environment';

@Injectable()
export class RefinedSearchService {
 
  constructor(private http: HttpClient) {}
  basePath: string = environment.apiUrl;

  getRelatedTerms(query) {
    let url = this.basePath+"SuggestedTerms/Get/";
    return this.http.post(url,{'query':query},{headers: contentHeaders}).map(data => {
      return data
    }, err => {
      return null;
    });
  }
  

}
