import {Injectable} from "@angular/core";
import {HttpClient} from "@angular/common/http";
import "rxjs/add/operator/map";
import {contentHeaders} from "../headers/auth-headers";
import { environment } from '../../../environments/environment';

@Injectable()
export class TechnologiesService {

  constructor(private http: HttpClient) { }

  basePath: string = environment.apiUrl;
  getTechnologies() {
    let url = this.basePath+"getTechnologies/";
    return this.http.get(url);
  }

}
