import {Injectable} from "@angular/core";
import {HttpClient} from "@angular/common/http";
import "rxjs/add/operator/map";
import {contentHeaders} from "../headers/auth-headers";
import { environment } from '../../../environments/environment';

@Injectable()
export class AddAnswerService {
 
  basePath: string = environment.apiUrl;
  constructor(private http: HttpClient) {
    console.log('basePath'+this.basePath);
  }

  AddAnswerDetails(addAnswer,parentId) {
    let url = this.basePath + "addKnowledge/addAnswer/";
    return this.http.post(url, {"answerBody":addAnswer,"parentId":parentId}, {headers: contentHeaders}).map(data => {
      return data
    }, err => {
      return null;
    });
  }
  
}
