import { TestBed, inject } from '@angular/core/testing';

import { AddanswerService } from './addanswer.service';

describe('AddanswerService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [AddanswerService]
    });
  });

  it('should be created', inject([AddanswerService], (service: AddanswerService) => {
    expect(service).toBeTruthy();
  }));
});
