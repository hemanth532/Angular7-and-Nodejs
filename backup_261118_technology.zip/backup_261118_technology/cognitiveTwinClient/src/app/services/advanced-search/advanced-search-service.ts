import {Injectable} from "@angular/core";
import {HttpClient} from "@angular/common/http";
import "rxjs/add/operator/map";
import {contentHeaders} from "../headers/auth-headers";
import { environment } from '../../../environments/environment';

@Injectable()
export class AdvancedSearchService {
 
  basePath: string = environment.apiUrl;
  constructor(private http: HttpClient) {
    console.log('basePath'+this.basePath);
  }

  createAdvSearchDetails(AdvancedSearchDetails) {
    let AdvObj = {'query':'','technology':'','userId':'','searchName':''};
    AdvObj.query = AdvancedSearchDetails.SearchQuery;
    AdvObj.technology = AdvancedSearchDetails.techoologies;
    AdvObj.userId = localStorage.getItem('userId');
    AdvObj.searchName = AdvancedSearchDetails.SearchName;
    console.log('AdvancedSearchDetails'+JSON.stringify(AdvObj));
    let url = this.basePath + "PersonalisedSearch/Add/";
    return this.http.post(url, AdvObj, {headers: contentHeaders}).map(data => {
      return data
    }, err => {
      return null;
    });
  }
  getAdvSearchDetails() {
    let userId = localStorage.getItem('userId');
    let url = this.basePath +"PersonalisedSearch/Get/";
    return this.http.post(url,{'userId':userId} ,{headers: contentHeaders}).map(data => {
      return data
    }, err => {
      return null;
    });
  }
  updateAdvSearchDetails(updateAdvSearchDetails) {
    let updateObj = {'searchId':'','technology':'','query':''};
    updateObj.searchId = updateAdvSearchDetails._id;
    updateObj.technology = updateAdvSearchDetails._source.technology;
    updateObj.query = updateAdvSearchDetails._source.query;
    console.log('AdvancedSearchDetails'+JSON.stringify(updateObj));
    let url = this.basePath +"PersonalisedSearch/Update/";
    return this.http.post(url, updateObj, {headers: contentHeaders}).map(data => {
      return data
    }, err => {
      return null;
    });
  }
  removeAdvSearchDetails(removeAdvSearchDetails) {
    let removeitemID = removeAdvSearchDetails._id;
    console.log('removeitemID'+removeitemID);
    let url = this.basePath +"PersonalisedSearch/Remove/";
    return this.http.post(url, {'itemId':removeitemID}, {headers: contentHeaders}).map(data => {
      return data
    }, err => {
      return null;
    });
  }
  

}
