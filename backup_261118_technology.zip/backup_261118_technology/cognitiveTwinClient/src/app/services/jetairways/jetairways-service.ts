import {Injectable} from "@angular/core";
import {HttpClient} from "@angular/common/http";
import "rxjs/add/operator/map";
import {contentHeaders} from "../headers/auth-headers";
import { environment } from '../../../environments/environment';

@Injectable()
export class JetAirwaysService {
 
  constructor(private http: HttpClient) {}
  basePath: string = environment.apiUrl;

getAirwaysAreas() {
   let url = this.basePath+"jetAirways/getAreas/";
   // let url = "assets/data/getAirwaysAreas.json";
    return this.http.get(url,{headers: contentHeaders});
}
fetchAirwaysData(data) {
   let url = this.basePath+"jetAirways/get/";
  //let url = "assets/data/fetchAirwaysData.json";
  return this.http.post(url,{'query':data.query},{headers: contentHeaders});
}
  
}
