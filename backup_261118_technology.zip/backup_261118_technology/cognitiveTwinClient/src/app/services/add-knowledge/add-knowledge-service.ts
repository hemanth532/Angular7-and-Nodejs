import {Injectable} from "@angular/core";
import {HttpClient} from "@angular/common/http";
import "rxjs/add/operator/map";
import {contentHeaders} from "../headers/auth-headers";
import { environment } from '../../../environments/environment';

@Injectable()
export class AddKnowledgeService {
 
  basePath: string = environment.apiUrl;
  constructor(private http: HttpClient) {
    console.log('basePath'+this.basePath);
  }

  addKnowledgeDetails(addKnowledgeDetails) {
    console.log('addKnowledgeDetails'+JSON.stringify(addKnowledgeDetails));
    let url = this.basePath + "addKnowledge/addQA/";
    return this.http.post(url, {"title":addKnowledgeDetails.question,"questionBody":addKnowledgeDetails.question,"tags":addKnowledgeDetails.Tags,
    "answerBody":addKnowledgeDetails.answer,"technology":addKnowledgeDetails.Technology}, {headers: contentHeaders}).map(data => {
      return data
    }, err => {
      return null;
    });
  }
  
}
