import {Injectable} from "@angular/core";
import {HttpClient} from "@angular/common/http";
import "rxjs/add/operator/map";
import {contentHeaders} from "../headers/auth-headers";
import { environment } from '../../../environments/environment';

@Injectable()
export class ProfileService {

  constructor(private http: HttpClient) {}

  basePath: string = environment.apiUrl;

  getProfileDetails() {
    let userId = localStorage.getItem('userId');
    let url = this.basePath+"userprofile/get/";
    return this.http.post(url, {'userId':userId}, {headers: contentHeaders}).map(data => {
      return data
    }, err => {
      return null;
    });
  }
}
