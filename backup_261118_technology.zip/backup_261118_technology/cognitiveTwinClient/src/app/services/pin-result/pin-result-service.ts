import {Injectable} from "@angular/core";
import {HttpClient} from "@angular/common/http";
import "rxjs/add/operator/map";
import {contentHeaders} from "../headers/auth-headers";
import { environment } from '../../../environments/environment';

@Injectable()
export class PinResultService {
 
  constructor(private http: HttpClient) {}
  basePath: string = environment.apiUrl;
  savePinDetails(savePinDetails,query,techoologies) {
    //console.log('savePinDetails'+JSON.stringify(savePinDetails));
    let userId = localStorage.getItem('userId');
    let savePinnedDetails = {'userId':userId,'title':savePinDetails._source.Title,'questionId':savePinDetails._source.Id,
    'questionBody':savePinDetails._source.Body,'answerId':'','answerBody':'','isPinned':savePinDetails._source.isPinned,'rating':'',
    'id':savePinDetails._id,'query':query,'technology':techoologies};
    console.log('savePinDetails'+JSON.stringify(savePinnedDetails));
    let url = this.basePath+"pinResult/save/";
    return this.http.post(url, savePinnedDetails, {headers: contentHeaders}).map(data => {
      return data
    }, err => {
      return null;
    });
  }
  getPinDetails() {
    //console.log('getPinDetails'+JSON.stringify(getPinDetails));
    let userId = localStorage.getItem('userId');
    let url = this.basePath+"pinResult/get/";
    return this.http.post(url, {'userId':userId}, {headers: contentHeaders}).map(data => {
      return data
    }, err => {
      return null;
    });
  }
  removePinDetails(removePinDetails) {
    console.log('removePinDetails'+JSON.stringify(removePinDetails));
    let url = this.basePath+"pinResult/remove/";
    return this.http.post(url, {'itemId':removePinDetails._id}, {headers: contentHeaders}).map(data => {
      return data
    }, err => {
      return null;
    });
  }
  removeAllPinDetails(removeAllPinDetails) {
    console.log('removeAllPinDetails'+JSON.stringify(removeAllPinDetails));
    let url = this.basePath+"pinResult/removeAll/";
    return this.http.post(url, {'itemIds':removeAllPinDetails}, {headers: contentHeaders}).map(data => {
      return data
    }, err => {
      return null;
    });
  }
  
}
