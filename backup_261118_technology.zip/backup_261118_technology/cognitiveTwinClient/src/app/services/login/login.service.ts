import {Injectable} from "@angular/core";
import {HttpClient} from "@angular/common/http";
import "rxjs/add/operator/map";
import {contentHeaders} from "../headers/auth-headers";
import {Router} from "@angular/router";
import {AuthHttp} from "angular2-jwt";
import {jwt_decode} from "jwt-decode";
import * as decode from "jwt-decode";
import { environment } from '../../../environments/environment';

@Injectable()
export class LoginService {
  jwt: string;
  decodedJwt: string;
  response: string;
  api: string;
  username: string;

  private isUserLoggedIn;
  basePath: string = environment.apiUrl;
  constructor(public router: Router, private http: HttpClient) {
    this.jwt = localStorage.getItem("token");
    //this.decodedJwt = this.jwt && jwt_decode(this.jwt);
  }

  logout() {
    localStorage.removeItem("token");
    localStorage.removeItem("userName");
    localStorage.removeItem("userId");
    this.isUserLoggedIn = false;
    this.router.navigate(["login"]);
  }

  setUserLoggedIn(status: boolean) {
    this.isUserLoggedIn = status;
  }

  getUserLoggedIn() {
    return this.isUserLoggedIn;
  }

  set_username(username) {
    this.username = username;
  }

  get_username() {
    return this.username;
  }

  login(loginDetails) {
    console.log('loginDetails'+loginDetails);
    let url = this.basePath+"sessions/create/";
    console.log('url'+url);
    return this.http.post(url, loginDetails, {headers: contentHeaders}).map(data => {
      return data
    }, err => {
      return null;
    });
  }

}
