import {Injectable} from "@angular/core";
import {HttpClient} from "@angular/common/http";
import "rxjs/add/operator/map";
import {contentHeaders} from "../headers/auth-headers";
import { environment } from '../../../environments/environment';

@Injectable()
export class SearchHistoryService {
 
  constructor(private http: HttpClient) {}
  basePath: string = environment.apiUrl;

  saveSearchHistory(query,technology) {
    console.log('saveSearchHistoryDetails'+JSON.stringify(query));
    let userId = localStorage.getItem('userId');
    let saveHistoryDetails = {'query':query,'technology':technology,'userId':userId};
    let url = this.basePath+"searchHistory/save/";
    return this.http.post(url, saveHistoryDetails, {headers: contentHeaders}).map(data => {
      return data
    }, err => {
      return null;
    });
  }
  getSearchHistory() {    
    let userId = localStorage.getItem('userId');
    let url = this.basePath+"searchHistory/get/";
    return this.http.post(url, {'userId':userId}, {headers: contentHeaders}).map(data => {
      return data
    }, err => {
      return null;
    });
  }
  removeSearchHistory(itemId) {
    let url = this.basePath+"searchHistory/remove/";
    return this.http.post(url, {'itemId':itemId}, {headers: contentHeaders}).map(data => {
      return data
    }, err => {
      return null;
    });
  }
  removeAllSearchHistory(itemId) {
    console.log('itemId'+JSON.stringify(itemId));
    let itemIds= itemId;
    let url = this.basePath+"searchHistory/removeMulti/";
  return this.http.post(url, {'itemIds':itemIds},{headers: contentHeaders}).map(data => {
      return data
    }, err => {
      return null;
    });
  }
  
}
