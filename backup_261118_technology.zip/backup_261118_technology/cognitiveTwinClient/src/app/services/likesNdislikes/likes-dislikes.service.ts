import {Injectable} from "@angular/core";
import {HttpClient} from "@angular/common/http";
import "rxjs/add/operator/map";
import {contentHeaders} from "../headers/auth-headers";
import { environment } from '../../../environments/environment';

@Injectable()
export class LikesDislikesService {
 
  basePath: string = environment.apiUrl;
  constructor(private http: HttpClient) {
    console.log('basePath'+this.basePath);
  }

  likesDisLikes(obj) {
    console.log('likes dis lieks obj'+JSON.stringify(obj));
    let url = this.basePath + "voting/update/";
    return this.http.post(url, obj, {headers: contentHeaders}).map(data => {
      return data
    }, err => {
      return null;
    });
  } 
}
