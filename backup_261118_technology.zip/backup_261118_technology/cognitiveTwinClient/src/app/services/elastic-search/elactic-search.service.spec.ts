import { TestBed, inject } from '@angular/core/testing';

import { ElacticSearchService } from './elactic-search.service';

describe('ElacticSearchService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ElacticSearchService]
    });
  });

  it('should be created', inject([ElacticSearchService], (service: ElacticSearchService) => {
    expect(service).toBeTruthy();
  }));
});
