import {Injectable} from '@angular/core';
import {Observable} from 'rxjs/Observable';
import {Subject} from 'rxjs/Subject';
import {contentHeaders} from "./../headers/auth-headers";
import { environment } from '../../../environments/environment';
import {HttpClient} from "@angular/common/http";

@Injectable()
export class ElacticSearchService {

  userId: string;
  query = '';
  basePath: string = environment.apiUrl;
  constructor( private http: HttpClient) {
  
  }
  set_userId(userId) {
    this.userId = userId;
  }

  get_userId() {
    return this.userId;
  }
  
getQueryResults(queryResults) {
  console.log('queryResults'+JSON.stringify(queryResults));
  let url = this.basePath +"queryResults/get/";
  return this.http.post(url,queryResults, {headers: contentHeaders}).map(data => {
    return data
  }, err => {
    return null;
  });    
}

}
