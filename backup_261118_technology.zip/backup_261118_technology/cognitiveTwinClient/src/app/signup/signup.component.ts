import { Component, OnInit,ViewChild,ElementRef,TemplateRef } from '@angular/core';
import { Router } from '@angular/router';
import { SignUpService } from '../services/signup/signup.service'
import {SearchOverlayService} from './../shared/services/search-overlay.service';
import { DialogpopupComponent } from './../dialogpopup/dialogpopup.component';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material';
import { ProjectDetailsService } from './../services/project-details/project-details-service' 
@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {

  constructor(private router: Router,private signupservice:SignUpService,
    private previewDialog :SearchOverlayService,public dialog: MatDialog,private projectdetailsservice:ProjectDetailsService) { }
  newUserDetails:any =  {'default':'no'};
  customErrorMessage: any;
  accessabilityVoice: boolean = false;
  fetchProjectDetails:any = [];
  @ViewChild('modalConnectedElement') modalConnectedElement: ElementRef;
  @ViewChild('invalid_user_exist') invalid_user_exist: TemplateRef<any>;
  ngOnInit() {
    if(localStorage.getItem('accessabilityVoice') == 'true'){
      this.accessabilityVoice = true;
   }
   this.projectDetails();
  }
  signUp(){
      return this.signupservice.signup(this.newUserDetails)
        .subscribe(response => {
          if(response['success']){
            this.router.navigate(['/']);
          } 
          else{
            this.customErrorMessage = response['message'];
          /*  this.previewDialog.open({
              connectedElement: this.modalConnectedElement,
              templateRef: this.invalid_user_exist
            });*/
            this. openDialog();
          }
        },
        error=>{
          console.log('error'+error);
        }
      );
    }
    projectDetails(){
      return this.projectdetailsservice.getProjectDetails()
      .subscribe(response => {
          this.fetchProjectDetails = response;
      },
      error=>{
        console.log('error'+error);
      }
    );
    }
    openDialog(): void {
      const dialogRef = this.dialog.open(DialogpopupComponent, {
        data: this.customErrorMessage
      });
    
      dialogRef.afterClosed().subscribe(result => {
        console.log('The dialog was closed');
      });
    }
    accessabilityChange(event){
      this.accessabilityVoice = event.checked;
      let abc = JSON.stringify(this.accessabilityVoice);
      localStorage.setItem('accessabilityVoice',abc);
    }
    defaultSelect(event){
      if(event.checked == true){
        this.newUserDetails.default = 'yes';
      }
      else{
        this.newUserDetails.default = 'no';
      }
    }
}
