import {Component, EventEmitter, OnInit, Output} from '@angular/core';
import {ElacticSearchService} from '../../services/elastic-search/elactic-search.service';
import {LoginService} from '../../services/login/login.service';

@Component({
  selector: 'app-search-search-header',
  templateUrl: './search-header.component.html',
  styleUrls: ['./search-header.component.css']
})
export class SearchHeaderComponent implements OnInit {

  constructor(private es: ElacticSearchService, private user: LoginService,) { }
  @Output() getUpdatedResult= new EventEmitter<any>();
  username;
  ngOnInit() {
    this.username = this.user.get_username();

  }

  refershSearchResults(event, query){
    //this.es.set_query(query)
    //this.es.getAndSetQueAndAnswers();
  }



}
