import {Component, ElementRef, EventEmitter, OnInit, Output, TemplateRef, ViewChild} from '@angular/core';
import {ElacticSearchService} from '../../services/elastic-search/elactic-search.service';
import {LoginService} from '../../services/login/login.service';
import {SearchOverlayService} from '../../shared/services/search-overlay.service';
import {TECHNOLOGIES} from '../../shared/constants';
import { TechnologiesService } from '../../services/technologies/technologies.service'
import {Router,ActivatedRoute} from '@angular/router';
import {CommonService } from '../../shared/services/common-service';
import {JetAirwaysService} from '../../services/jetairways/jetairways-service'
import { from } from 'rxjs/observable/from';
declare var responsiveVoice:any;
@Component({
  selector: 'app-search-result-header',
  templateUrl: './result-header.component.html',
  styleUrls: ['./result-header.component.css']
})
export class ResultHeaderComponent implements OnInit {

  constructor(private es: ElacticSearchService, private user: LoginService,
     private previewDialog: SearchOverlayService,public router: Router,
     private route: ActivatedRoute,
     private commonservice:CommonService,
     private technologiesservice:TechnologiesService,
     private jetairwayservice:JetAirwaysService) {
  }

  @Output() getUpdatedResult = new EventEmitter<any>();

  @ViewChild('modalConnectedElement') modalConnectedElement: ElementRef;
  @ViewChild('personalized_search') personalizedSearch: TemplateRef<any>;
  @ViewChild('search_history') searchHistory: TemplateRef<any>;
  @ViewChild('advance_search') advanceSearch: TemplateRef<any>;
  togglePersonalized: boolean = false;
  technologies:any = [];
  selectedValue:any;
  selectedArea:any;
  username;
  query = '';
  searchTime:any;
  searchRecordCount:any;
  pageName:any;
  projectDetails: string;
  projectDefault: string;
  projectName;
  airwayareas:any = [];
  defaultPro = localStorage.getItem('default');
 
  ngOnInit() {
    this.route.params.subscribe(param => {
      console.log('param'+JSON.stringify(param));
      this.pageName = param.pageName ;
      if(param.pageName != undefined && param.pageName == "result"){
        this.selectedValue = param.techoologies;
        this.selectedArea = param.techoologies;
        this.projectName = param.projectName;
       // alert(this.projectName)
        this.refershSearchResults(event, param.SearchQuery);
      }
    })  
    //this.username = this.user.get_username();
    this.username = localStorage.getItem('userName')
    //this.projectDetails = localStorage.getItem('projectName')
    console.log(' this.username'+ this.username);
    //this.query =  this.es.get_query();
    //console.log('this.query'+this.query);
      this.getSearchTime();
      this.technologiesservice.getTechnologies().subscribe(res=>{
     
        this.technologies  = res;
    }, err=>{
      
      console.log(err);
    })
    this.getAirwayAreas();
    this.commonservice.currentseletectedTechSource.subscribe(message =>{
     // alert(message);
      this.projectDefault = localStorage.getItem('projectName')
      this.projectDetails = message;
      if(this.projectDetails){
        this.selectedValue =  this.projectDetails;
        this.projectName = message;
       // alert(this.selectedValue);
      }
      else{
        this.projectDetails = 'Default';
      }
    }, error=>{
      console.log('error'+error);
    });
  }
  getAirwayAreas(){
    this.jetairwayservice.getAirwaysAreas().subscribe(res=>{
      this.airwayareas = res;
  }, err=>{
    
    console.log(err);
  })
  }
  getSearchTime(){
    this.commonservice.currentSearchTimeSource.subscribe(message =>{
      this.searchTime = (message.searchTime/1000).toFixed(2);
      this.searchRecordCount = message.searchRecordCount;
    }, error=>{
      console.log('error'+error);
    });
  }
  refershSearchResults1(event, query){
    if(event.keyCode === 13){
      this.refershSearchResults(event, query);
      this.navigateToResultPage(query);
    }
  }
  refershSearchResults(event, query) {
    if(localStorage.getItem('accessabilityVoice') == 'true'){
    let voiceQuery = "Searching "+query;
    responsiveVoice.speak(voiceQuery,'US English Female');
    }
    //this.es.set_query(query);
    this.query = query// this.es.get_query();
   // this.commonservice.changeQuestionNAnser(this.query)
    //this.es.getAndSetQueAndAnswers();
  }

  showPersonalized() {
    // this.showPersonalizedFlag = !this.showPersonalizedFlag;
    /*this.previewDialog.open({
      connectedElement: this.modalConnectedElement,
      templateRef: this.personalizedSearch
    });*/
    this.togglePersonalized = !this.togglePersonalized;
  }
  doAction(AssObj: any){
    // alert('called');
     this.togglePersonalized = AssObj;
   }
  showHistory() {
    this.previewDialog.open({
      connectedElement: this.modalConnectedElement,
      templateRef: this.searchHistory
    });
  }

  advanceSearchHandler() {
    this.previewDialog.open({
      connectedElement: this.modalConnectedElement,
      templateRef: this.advanceSearch
    });
  }
  logout() {
    if(localStorage.getItem('accessabilityVoice') == 'true'){
    responsiveVoice.speak('You are signing off','US English Female');
    }
    localStorage.removeItem('token');
    localStorage.removeItem("userName");
    localStorage.removeItem("userId");
    this.user.setUserLoggedIn(false);
    this.router.navigate(['login']);
  }
  pageSelected(page){
    this.router.navigate(['/search-result',page]);
  }
  navigateToResultPage(query){
    if(this.projectName == 'Jet Airways'){ 
      this.router.navigate(['/search-result',query,this.selectedArea,'result',this.projectDetails]);
    }
    else{
      this.router.navigate(['/search-result',query,this.selectedValue,'result',this.projectDetails]);
    }
    this.commonservice.changeupdatePageVal(1);
  }
  
}
