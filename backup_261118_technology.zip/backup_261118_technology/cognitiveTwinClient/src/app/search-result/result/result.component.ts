import {Component, Input, OnInit} from '@angular/core';
import {MatDrawer} from '@angular/material';
import { MailService } from '../../services/mail/mail-service'
import { PinResultService } from '../../services/pin-result/pin-result-service';
import { SearchHistoryService } from '../../services/search-history/search-history-service'
import {ActivatedRoute} from '@angular/router';
import { CommonService } from '../../shared/services/common-service'
import {ElacticSearchService} from '../../services/elastic-search/elactic-search.service';
import {LikesDislikesService} from '../../services/likesNdislikes/likes-dislikes.service'
import {JetAirwaysService } from '../../services/jetairways/jetairways-service'
import { environment } from '../../../environments/environment';
declare var _;

@Component({
  selector: 'app-search-result-content',
  templateUrl: './result.component.html',
  styleUrls: ['./result.component.css']
})
export class ResultComponent implements OnInit {

  @Input() drawerRef: MatDrawer;
   questions: any = {};
   answers: any = {};

  length = 100;
  pageSize = 10;
  p=1;
  pageSizeOptions = [5, 10, 25, 100];
  openMailPopup: any;
  emailId: any;
  pinEnableDisalbe: boolean = false;
  mailIdCc:any;
  //pageNameSelected:any;
  query:any;
  project:any;
  project_backup:any;
  searchBeforeTime:any;
  searchAfterTime:any;
  pinnedResult:any;
  getquestions:any;
  //answersList :any;
  questionList:any;
  display: string;
  techoologies:any
  questionListTemp:any = {"questions": []};
  jetAirwaysObjTemp:any;
  thumpsup:boolean = false;
  thumpsdown:boolean = false;
  addknowledgeHideShow: boolean = false;
  addAnswerHideShow: boolean = false;
  selectedindexresult:number = 0;
  jetAirwaysObj:any = [];
  defaultPro = localStorage.getItem('default');
  basePath: string = environment.apiUrlDoc;
  
  constructor(private mailservice:MailService,private pinresultservice:PinResultService,
    private searchhistoryservice: SearchHistoryService,private route :ActivatedRoute,
    private commonservice:CommonService,private es :ElacticSearchService,
    private likesdislikesservice:LikesDislikesService,
    private jetairwayservice:JetAirwaysService) {
  }

  ngOnInit() {
    this.project_backup = localStorage.getItem('projectName');
    console.log('project_backup'+this.project_backup);
    this.route.params.subscribe(param => {
      this.query = param.SearchQuery;
      this.techoologies = param.techoologies;
      this.project = param.projectName;
     // alert('this.project'+this.project);
      if(this.project_backup == 'default' ){
        this.defaultPro = 'yes';
      }
      this.commonservice.changeSeletectedFilter(this.project);
      if(this.project == 'Default' || this.project == 'ppms'){
          this.selectedindexresult = 0;
          this.commonservice.changeSeletectedTech(this.project);
          if(this.project == 'ppms'){
            this.selectedindexresult = 2;
           // this.commonservice.changeSeletectedTech(this.project);
          }
          document.getElementById('loading').style.display = "block";
          this.searchhistoryservice.saveSearchHistory(param.SearchQuery,this.techoologies).subscribe(result => {
            this.searchBeforeTime = Date.now();
          //  this.getAllQuestions(this.query);
              this.getQueryResults();
          })
         
           /*new code added */
          this.mailIdCc = localStorage.getItem('userId');
          this.commonservice.currentupdatePageValSource.subscribe(message =>{
            this.p = message;
          }, error=>{
            console.log('error'+error);
          });
      }
      else{
        //alert('else');
        this.selectedindexresult = 2;
        document.getElementById('loading').style.display = "block";
        this.commonservice.changeSeletectedTech(this.project);
        //alert( this.query );
        //alert(this.techoologies);
        this.searchhistoryservice.saveSearchHistory(this.query ,this.techoologies).subscribe(result => {
          this.searchBeforeTime = Date.now();
           this.fetchAirwaysData();
        })
      }
      if(this.questionListTemp){
        this.commonservice.currentselectedTermSource.subscribe(message =>{
        if(this.project == 'video'){
        //  alert(message);
          this.questions.videoList = this.filterByVideos(this.questionListTemp.videoList,message);
        }
        else  if(this.project == 'Jet Airways'){
          this.jetAirwaysObj = this.filterByJetAirways(this.jetAirwaysObjTemp,message);
        }
        else{
          this.questions.questions = this.filterByQuestions(this.questionListTemp.questions,message);
        }
       },
       error=>{
         console.log('error'+error);
       })
       }
    },
    error=>{
      console.log('error'+error);
    }) 
  }
  filterByVideos(data,sourceArr){
    //alert(sourceArr);
    var filtereData = [];
    if(sourceArr.length !== 0){
     _.map(data, function(d){ 
      _.map(sourceArr, function(srcArr){
          if (d._source.Module === srcArr){
           // alert(d._source.Module);
            filtereData.push(d);
            return;
            }
     })  
  });
}
     if(sourceArr.length ===0){
      // alert(sourceArr.length);
     return data;
     }
     else{
     return _.uniq(filtereData);
     }
  } 
  filterByQuestions(data,sourceArr){
    console.log(sourceArr);
    var filtereData = [];
    if(sourceArr.length !== 0){
     _.map(data, function(d){ 
      _.map(sourceArr, function(srcArr){
        var patt = new RegExp(srcArr);
        if(patt.test(d._source.Tags)){
            console.log(d._source.Tags);
            filtereData.push(d);
            return;
            }
     })  
  });
}
     if(sourceArr.length ===0){
      // alert(sourceArr.length);
     return data;
     }
     else{
     return _.uniq(filtereData);
     }
  } 
  filterByJetAirways(data,sourceArr){
    var filtereData = [];
    if(sourceArr.length !== 0){
     _.map(data, function(d){ 
      _.map(sourceArr, function(srcArr){
          if (d._source.created_date === srcArr){
           // alert(d._source.Module);
            filtereData.push(d);
            return;
            }
     })  
  });
}
     if(sourceArr.length ===0){
      // alert(sourceArr.length);
     return data;
     }
     else{
     return _.uniq(filtereData);
     }

  }
  fetchAirwaysData(){
    let userId = localStorage.getItem('userId');
    let getQueryResultsObj = {'project':this.project,'query':this.query,'tech':this.techoologies,'userId':userId};
    this.jetairwayservice.fetchAirwaysData(getQueryResultsObj).subscribe(result => {
      this.jetAirwaysObj = result;
      let resultSearchResutObj = JSON.stringify(result);
      this.jetAirwaysObjTemp =  JSON.parse(resultSearchResutObj);
      this.commonservice.changeResponseJetFilterSource(this.jetAirwaysObjTemp);
      this.searchAfterTime = Date.now();
      let serchTimeDiff = this.searchAfterTime - this.searchBeforeTime;
      this.commonservice.changeSearchTime({"searchTime":serchTimeDiff,"searchRecordCount": this.jetAirwaysObj.length})   
      document.getElementById('loading').style.display = "none";
    });
  }
  getQueryResults(){
    let userId = localStorage.getItem('userId');
      this.questionListTemp = {"questions": []};
      this.questionListTemp = '';
      this.questionList = '';
      this.questions = '';
      this.answers = '';
    let getQueryResultsObj = {'project':this.project,'query':this.query,'tech':this.techoologies,'userId':userId};
    this.es.getQueryResults(getQueryResultsObj).subscribe(result => {
      this.questions = result;
      let resultSearchResutObj = JSON.stringify(result);
      this.questionListTemp =  JSON.parse(resultSearchResutObj);
      this.commonservice.changeResponseFilterSource(this.questionListTemp.videoList);
      this.questionList =  JSON.parse(resultSearchResutObj);
      this.answers =  JSON.parse(resultSearchResutObj);
      this.searchAfterTime = Date.now();
      let serchTimeDiff = this.searchAfterTime - this.searchBeforeTime;
      this.commonservice.changeSearchTime({"searchTime":serchTimeDiff,"searchRecordCount": this.questions.questions.length})   
      document.getElementById('loading').style.display = "none";
    });
  }
  openMail(id){
      this.openMailPopup = id;
      this.emailId = '';
  }
  sendMail(question,mailId){
    //document.getElementById('loading').style.display="block";
   console.log('question'+JSON.stringify(question));
   let questionId = question._source.Id;
   let userName:any;
   if(mailId.indexOf('.') >= 0){
    var a = mailId.split('.');
     userName = a[0];
   }
   else if(mailId.indexOf('@') >= 0){
    var a = mailId.split('@');
     userName = a[0];
   }
   let ansArray = [];
   console.log('mailId'+mailId);
   for(let i=0;i<this.answers.answers.length;i++){
      if(this.answers.answers[i].ParentId == questionId){
        ansArray.push(this.answers.answers[i].Body);
      }
   }
   let userNameMe = localStorage.getItem('userName');
   this.mailservice.sendMail(question,ansArray,mailId,this.mailIdCc,userName,userNameMe).subscribe(response => {
    //document.getElementById('loading').style.display="none";
    },
  error=>{
    console.log('error'+JSON.stringify(error));
  })
  this.openMailPopup = false;
  this.emailId = '';
  }
  savePin(question,pinned,index){
    this.questions.questions[index]._source.isPinned = pinned;
     // this.pinEnableDisalbe = !this.pinEnableDisalbe;
     //alert('question._source.isPinned'+this.questions.response.hits.hits[index]._source.isPinned);
      document.getElementById('loading').style.display="block";
      
      if(pinned == 'true'){
        //alert('save');
        this.pinresultservice.savePinDetails(question,this.query,this.techoologies).subscribe(response => {
         // alert('success');
         document.getElementById('loading').style.display="none";
          },
        error=>{
          document.getElementById('loading').style.display="none";
          console.log('error'+error);
        })
      }
      else{
       // alert('remove');
        this.pinresultservice.removePinDetails(question).subscribe(response => {
          document.getElementById('loading').style.display="none";
        },
      error=>{
        document.getElementById('loading').style.display="none";
        console.log('error'+error);
      })
      }

  }
  like(i,searchValue){
   // this.thumpsup = true;
  //  this.thumpsdown = false;
  document.getElementById('loading').style.display="block";
  let index = -1;
  _.each(this.questions.questions, function(data, idx) { 
    if (_.isEqual(data, searchValue)) {
       index = idx;
       return;
    }
 });
    this.questions.questions[index]._source.vote = 'like';
    console.log(this.questions.questions[index]._source.likes);
    if(this.questions.questions[index]._source.likes == undefined){
      this.questions.questions[index]._source.likes = 1;
      console.log(this.questions.questions[index]._source.likes);
    }
    else{
      this.questions.questions[index]._source.likes++;
    }
    let userid  = localStorage.getItem('userId');
    this.likesdislikesservice.likesDisLikes({'vote':'like','questionId':this.questions.questions[index]._source.Id,
    'documentId':this.questions.questions[index]._id,'project':this.project,'userId':userid}).subscribe(message =>{
      document.getElementById('loading').style.display="none";
    }, error=>{
      console.log('error'+error);
      document.getElementById('loading').style.display="none";
    });
  }
  unLike(i,searchValue){
  //  this.thumpsup = false;
    //this.thumpsdown = true;
    document.getElementById('loading').style.display="block";
  let index = -1;
  _.each(this.questions.questions, function(data, idx) { 
    if (_.isEqual(data, searchValue)) {
       index = idx;
       return;
    }
 });
    this.questions.questions[index]._source.vote = 'dislike'
    if(this.questions.questions[index]._source.dislikes == undefined){
      this.questions.questions[index]._source.dislikes = 1;
      console.log(this.questions.questions[index]._source.dislikes);
    }
    else{
      this.questions.questions[index]._source.dislikes++;
    }
    let userid  = localStorage.getItem('userId');
    this.likesdislikesservice.likesDisLikes({'vote':'dislike','questionId':this.questions.questions[index]._source.Id,
    'documentId':this.questions.questions[index]._id,'project':this.project,'userId':userid}).subscribe(message =>{
      document.getElementById('loading').style.display="none";
     }, error=>{
       console.log('error'+error);
       document.getElementById('loading').style.display="none";
     });
  }
  addKnowledge(){
    this.addknowledgeHideShow = !this.addknowledgeHideShow;
    if(this.addknowledgeHideShow){
      document.getElementById('addKnowledge').style.position = "relative"; 
    }
    else{
      document.getElementById('addKnowledge').style.position = "absolute";
    }
  }
  addAnswer(){
    this.addAnswerHideShow = !this.addAnswerHideShow;
  }
  tabClicked(event){
    //this.project = tab;
    if(event.index == 0){
      //document.getElementById('loading').style.display = "block";
      this.project = 'Default';
      this.commonservice.changeSeletectedTech(this.project);
      this.commonservice.changeSeletectedFilter(this.project);
     // this.getQueryResults();
    } 
    else if(event.index == 1){
      this.project = 'video';
      this.commonservice.changeSeletectedFilter(this.project);
      this.commonservice.changeSeletectedTech(this.project);
    }
    else{
     // document.getElementById('loading').style.display = "block";
      this.project = this.project_backup;
      //alert(this.project);
      this.commonservice.changeSeletectedTech(this.project);
      this.commonservice.changeSeletectedFilter(this.project);
      //this.getQueryResults();
    }
  }
}
