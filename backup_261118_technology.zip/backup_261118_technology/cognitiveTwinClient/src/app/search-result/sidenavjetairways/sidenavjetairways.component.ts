import { Component, OnInit } from '@angular/core';
import { CommonService } from '../../shared/services/common-service'
declare var _;
@Component({
  selector: 'app-sidenavjetairways',
  templateUrl: './sidenavjetairways.component.html',
  styleUrls: ['./sidenavjetairways.component.css']
})
export class SidenavjetairwaysComponent implements OnInit {
  relatedTerms:any = [];
  selectedValue=''
  Searchquery:any;
  selectedTersm:any[] = [];
  constructor(private commonservice:CommonService) { }

  ngOnInit() {
    this.commonservice.currentresponseJetFilterSource.subscribe(message =>{
      let result = message;
      if(result.length != 0){
        this.relatedTerms = this.removeDuplicates(result);
      console.log('result'+JSON.stringify(this.removeDuplicates(result)));
      }
   })
  }
 removeDuplicates(arr){
  return _.uniq(arr, function(p){ return p._source.created_date; });
//   _.uniq(arr,'Module');
}
  relatedTermsSelect(term,event){
    if(event.checked == true){
      this.selectedTersm.push(term);
    }
    else{
    let index = this.selectedTersm.indexOf(term);
    if (index > -1) {
      this.selectedTersm.splice(index, 1);
      }
    }
    console.log('this.selectedTersm'+this.selectedTersm);
    this.commonservice.changeSelectedTerm(this.selectedTersm)
  }
}
