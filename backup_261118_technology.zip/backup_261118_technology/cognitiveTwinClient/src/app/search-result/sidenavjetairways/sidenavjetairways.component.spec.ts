import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SidenavjetairwaysComponent } from './sidenavjetairways.component';

describe('SidenavjetairwaysComponent', () => {
  let component: SidenavjetairwaysComponent;
  let fixture: ComponentFixture<SidenavjetairwaysComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SidenavjetairwaysComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SidenavjetairwaysComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
