import {Component, OnInit, ViewChild, Pipe, PipeTransform} from '@angular/core';
import {MatSidenav} from '@angular/material/sidenav';
//import {ElacticSearchService} from '../services/elastic-search/elactic-search.service';
//import {DefaultSearchComponent} from '../search/default-search/default-search.component';
//import {LoginService} from '../services/login/login.service';
import { CommonService } from '../shared/services/common-service'
import {ActivatedRoute} from '@angular/router';

//import { SearchHistoryService } from '../services/search-history/search-history-service'
//import { PinResultService } from '../services/pin-result/pin-result-service'

@Component({
  selector: 'app-search-result',
  templateUrl: './search-result.component.html',
  styleUrls: ['./search-result.component.css']
})

export class SearchResultComponent implements OnInit {
  accessabilityVoice: boolean = false;
  /*transform(value, args:string[]) : any {
    let keys = [];
    for (let key in value) {
      keys.push({key: key, value: value[key]});
    }
    return keys;
  }*/

  @ViewChild('sidenav') sidenav: MatSidenav;


 // query = '';
  //display: string;

  //mapAnswer = new Map();
  //mapQuestion = new Map<String, String>();

  //answersList :any;
  //questionList:any;
  //questionListTemp:any = {"response": {"hits": {"hits": [{"_source":""}]}}};

  //questionListDetailed:any = [];

  //questionsObj = [];
  pageNameSelected: any;
  selectedFilter:any;
  //searchBeforeTime:any;
  //searchAfterTime:any;
  //pinnedResult:any;
  //getquestions:any;
  constructor(private route :ActivatedRoute,private commonservice:CommonService) {
  }


  ngOnInit() {
    if(localStorage.getItem('accessabilityVoice') == 'true'){
      this.accessabilityVoice = true;
   }
   
    this.route.params.subscribe(param => {
      console.log('param_hemanth'+JSON.stringify(param));
      this.pageNameSelected = param.pageName;
      //this.query = param.SearchQuery;
    }) 
    this.commonservice.currentseletectedFilterSource.subscribe(message =>{
      this.selectedFilter = message;
     });
   // this.mapAnswer = this.es.get_ansMap();
    //this.mapQuestion = this.es.get_quesMap();
    //this.es.getAndSetQueAndAnswers();
   /* this.es.get_ansList().subscribe(result => {
      this.answersList = result;
     // console.log(this.answersList);
    });*/
    
   /* this.es.get_questList().subscribe(result => {
      this.questionList = result;
      this.questionListTemp = result;
      this.questionListDetailed = result;
    });*/
   /* this.commonservice.currentquestionNAnserSource.subscribe(message =>{
      //alert(message);
      this.searchBeforeTime = Date.now();
     this.getAllQuestions(message);
     });
     
if(this.questionListTemp){
     this.commonservice.currentselectedTermSource.subscribe(message =>{
      let selectedTersm = {'response':{'hits':{'hits':[]}}};
      for(let i=0;i<message.length;i++){
        for(let j=0;j<this.questionListTemp.response.hits.hits.length;j++){
          var patt = new RegExp(message[i]);
          if(patt.test(this.questionListTemp.response.hits.hits[j]._source.Tags)){
            selectedTersm.response.hits.hits.push(this.questionListTemp.response.hits.hits[j]);
          }        
        }
      }
      
      if(selectedTersm.response.hits.hits.length != 0 ){
        console.log('selectedTersm'+JSON.stringify(selectedTersm));
        //this.questionListDetailed = selectedTersm;
        this.questionListDetailed = selectedTersm;
      }
      else{
        this.questionListDetailed = this.questionList;
        //console.log(' this.questionListDetailed'+JSON.stringify(this.questionListDetailed));
      }
    })
}*/


    //this.set_query(this.search.get_query());
    //this.query = this.es.get_query();
    /*console.log('this.queryhemanth'+this.query );
    this.display = this.query;*/
    //console.log(this.query);
    // console.log(this.get_ansList());
    //   console.log(this.get_quesList());
  }
  /*getAllQuestionsWithPinnedStatus(){
    this.es.getAllQuestionsWithPinnedStatus(this.pinnedResult ,this.getquestions).subscribe(result => {
      this.questionListDetailed = result;
      console.log('questionListDetailed'+JSON.stringify(this.questionListDetailed));
      this.questionListTemp = result;
      this.questionList = result;
      this.getAllAnswers(result);
    });
  }
  getPinnedItems(){
    this.pinresultservice.getPinDetails().subscribe(result => {
        this.pinnedResult = result;
        this.getAllQuestionsWithPinnedStatus();
    });
  }
  getAllQuestions(query){
    if(query){
      this.query = query;
    }
    this.es.getAllQuestions(this.query).subscribe(result => {
      console.log('result'+JSON.stringify(result));
      this.getquestions = result;
      this.getPinnedItems();
      //this.questionListDetailed = result;
      //this.questionListTemp = result;
      //this.questionList = result;
      //this.getAllAnswers(result);
    });
  }
  getAllAnswers(result){
    this.es.getAllAnswers(result).subscribe(result => {
      //this.questionList = result;
      this.answersList  = result;
      this.searchAfterTime = Date.now();
      let serchTimeDiff = this.searchAfterTime - this.searchBeforeTime;
      this.commonservice.changeSearchTime({"searchTime":serchTimeDiff,"searchRecordCount": this.questionListDetailed.response.hits.hits.length})
      /*this.searchhistoryservice.saveSearchHistory(this.query).subscribe(result => {
      })*/
      //this.questionListTemp = result;
      //console.log('this.questionListTemp '+JSON.stringify(this.questionListTemp.response ));
      //this.questionListDetailed = result;
    //});
  //}
  /*New code*/
  /*viewportWidthToggle: boolean = false;
  autoWidthSideNav(){
    if(this.viewportWidthToggle == false){
      let viewportWidth = document.documentElement.clientWidth;
      let viewportWidthBody = viewportWidth - 229;
      document.getElementById('result_items').style.width = viewportWidthBody + 'px';
      this.viewportWidthToggle = ! this.viewportWidthToggle;
    }
    else{
      document.getElementById('result_items').style.width = '100%';
    }
  }*/
  accessabilityChange(event){
    this.accessabilityVoice = event.checked;
    let abc = JSON.stringify(this.accessabilityVoice);
    localStorage.setItem('accessabilityVoice',abc);
  }
}

