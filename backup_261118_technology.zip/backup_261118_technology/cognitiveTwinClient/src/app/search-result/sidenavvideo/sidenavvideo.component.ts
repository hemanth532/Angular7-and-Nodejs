import { Component, OnInit } from '@angular/core';
import {RefinedSearchService} from '../../services/refined-search/refined-search-service';
import { ElacticSearchService } from '../../services/elastic-search/elactic-search.service'
import { CommonService } from '../../shared/services/common-service'
import {Router,ActivatedRoute} from '@angular/router';
declare var _;
@Component({
  selector: 'app-sidenavvideo',
  templateUrl: './sidenavvideo.component.html',
  styleUrls: ['./sidenavvideo.component.css']
})
export class SidenavvideoComponent implements OnInit {
  relatedTerms:any = [];
  selectedValue=''
  Searchquery:any;
  selectedTersm:any[] = [];
  constructor( private refinedsearchservice: RefinedSearchService,private es: ElacticSearchService,
    private commonservice:CommonService,private route :ActivatedRoute) { }

  ngOnInit() {
    //document.getElementById('loading').style.display = "block";
    this.route.params.subscribe(param => {
      this.Searchquery = param.SearchQuery;
      let techoologies = param.techoologies;
      let project = param.projectName; 
    let userId = localStorage.getItem('userId');
    this.commonservice.currentresponseFilterSource.subscribe(message =>{
       let result = message;
       if(result.length != 0){
       this.relatedTerms = this.removeDuplicates(result);
       console.log('result'+JSON.stringify(this.removeDuplicates(result)));
       }
    })
   /* let getQueryResultsObj = {'project':project,'query':this.Searchquery,'tech':techoologies,'userId':userId};
    this.es.getQueryResults(getQueryResultsObj).subscribe(result => {
      let result1:any = result;
      this.relatedTerms = result1.videoList;
      document.getElementById('loading').style.display = "none";
    },
    error=>{
      console.log('error'+error);
    })*/
  }) 
  }
  removeDuplicates(arr){
    return _.uniq(arr, function(p){ return p._source.Module; });
  //   _.uniq(arr,'Module');
 }
  relatedTermsSelect(term,event){
    if(event.checked == true){
      this.selectedTersm.push(term);
    }
    else{
    let index = this.selectedTersm.indexOf(term);
    if (index > -1) {
      this.selectedTersm.splice(index, 1);
      }
    }
    console.log('this.selectedTersm'+this.selectedTersm);
    this.commonservice.changeSelectedTerm(this.selectedTersm)
  }
}
