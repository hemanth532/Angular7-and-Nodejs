import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SidenavvideoComponent } from './sidenavvideo.component';

describe('SidenavvideoComponent', () => {
  let component: SidenavvideoComponent;
  let fixture: ComponentFixture<SidenavvideoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SidenavvideoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SidenavvideoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
