import { Component, OnInit } from '@angular/core';
import {RefinedSearchService} from '../../services/refined-search/refined-search-service';
import { ElacticSearchService } from '../../services/elastic-search/elactic-search.service'
import { CommonService } from '../../shared/services/common-service'
import {Router,ActivatedRoute} from '@angular/router';

@Component({
  selector: 'app-search-result-sidenav',
  templateUrl: './sidenav.component.html',
  styleUrls: ['./sidenav.component.css']
})
export class SidenavComponent implements OnInit {
  selectedProject: string = 'Default';
  projects: string[] = ['All', 'Default'];
  selectedValue=''
  Searchquery:any;
  relatedTerms:any = [];
  selectedTersm:any[] = [];
  constructor( private refinedsearchservice: RefinedSearchService,private es: ElacticSearchService,
  private commonservice:CommonService,private route :ActivatedRoute) { }
  ngOnInit() {
    this.route.params.subscribe(param => {
      this.Searchquery = param.SearchQuery;
    })  
    //this.selectedProject = localStorage.getItem('projectName');
    this.projects.push(localStorage.getItem('projectName'));
    //this.Searchquery = this.es.get_query();
    //console.log('this.Searchquery'+JSON.stringify(this.Searchquery));
    this.commonservice.currentresponseFilterSource.subscribe(message =>{
     this.geRelatedTerms();
    })
   
  }
  geRelatedTerms(){
    this.refinedsearchservice.getRelatedTerms(this.Searchquery).subscribe(response => {
      this.relatedTerms = response;
     // alert();
      console.log('this.relatedTerms '+JSON.stringify(this.relatedTerms ));
  },
  error=>{
    console.log('error'+error);
  })
  }
  relatedTermsSelect(term,event){
    if(event.checked == true){
      this.selectedTersm.push(term);
    }
    else{
    let index = this.selectedTersm.indexOf(term);
    if (index > -1) {
      this.selectedTersm.splice(index, 1);
      }
    }
    console.log('this.selectedTersm'+this.selectedTersm);
    this.commonservice.changeSelectedTerm(this.selectedTersm)
  }
  /*projectChange(){
   // localStorage.setItem('projectName',this.selectedProject);
   this.commonservice.changeSeletectedTech(this.selectedProject);
  } */
}
