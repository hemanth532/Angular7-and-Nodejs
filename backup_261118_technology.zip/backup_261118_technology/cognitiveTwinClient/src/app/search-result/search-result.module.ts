import {NgModule} from '@angular/core';
import {SidenavComponent} from './sidenav/sidenav.component';
import {ResultComponent} from './result/result.component';
import {ResultHeaderComponent} from './result-header/result-header.component';
import {SearchModuleRouting} from './search-module.routing';
import {SearchResultComponent} from './search-result.component';
import {CommonModule} from '@angular/common';
import {FormsModule} from '@angular/forms';
import {SharedModule} from '../shared/shared.module';
import {CongitiveCommonModule} from '../common/common.module';
import {NgxPaginationModule} from 'ngx-pagination';
import {SearchModule} from '../search/search.module';
import {SearchHeaderComponent} from './search-header/search-header.component';
import { SidenavvideoComponent } from './sidenavvideo/sidenavvideo.component';
import { SidenavjetairwaysComponent } from './sidenavjetairways/sidenavjetairways.component';

@NgModule({
  imports: [CommonModule,
    FormsModule,
    SearchModuleRouting,
    SharedModule,
    SearchModule,
    CongitiveCommonModule,
    NgxPaginationModule],
  declarations: [
    SidenavComponent,
    ResultComponent,
    ResultHeaderComponent,
    SearchHeaderComponent,
    SearchResultComponent,
    SidenavvideoComponent,
    SidenavjetairwaysComponent],
  providers: []
})

export class SearchResultModule {

}
