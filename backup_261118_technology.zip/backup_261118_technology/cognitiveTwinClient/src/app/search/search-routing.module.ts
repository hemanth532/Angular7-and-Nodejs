import {NgModule} from '@angular/core';
import {RouterModule, Routes} from '@angular/router';
import {DefaultSearchComponent} from './default-search/default-search.component';
import {AdvancedComponent} from './advanced/advanced.component';
import {PersonalizedComponent} from './personalized/personalized.component';
import {HistoryComponent} from './history/history.component';
import {PinneditemsComponent} from './pinneditems/pinneditems.component';
import {UserprofileComponent} from './userprofile/userprofile.component';
import { AddknowledgeComponent } from './addknowledge/addknowledge.component';
import { AddanswerComponent } from './addanswer/addanswer.component'


const routes: Routes = [{
  path: '',
  component: DefaultSearchComponent,
}, {
  path: 'advanced',
  component: AdvancedComponent,
}, {
  path: 'history',
  component: HistoryComponent,
},
{
  path: 'userprofile',
  component: UserprofileComponent,
}, {
  path: 'personalized',
  component: PersonalizedComponent,
},{
  path: 'pinneditems',
  component: PinneditemsComponent,
},{
  path: 'addknowledge',
  component: AddknowledgeComponent,
},
{
  path: 'addanswer',
  component: AddanswerComponent,
}
];


@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports:[RouterModule]
})

export class SearchRoutingModule {

}

export const searchroutedComponents = [DefaultSearchComponent, PersonalizedComponent,
   AdvancedComponent, HistoryComponent,PinneditemsComponent,UserprofileComponent,
   AddknowledgeComponent,AddanswerComponent];
