import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PinneditemsComponent } from './pinneditems.component';

describe('PinneditemsComponent', () => {
  let component: PinneditemsComponent;
  let fixture: ComponentFixture<PinneditemsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PinneditemsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PinneditemsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
