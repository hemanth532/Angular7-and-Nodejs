import { Component, OnInit } from '@angular/core';
import { PinResultService } from '../../services/pin-result/pin-result-service';
import {Router } from '@angular/router';
import {CommonService } from '../../shared/services/common-service';
@Component({
  selector: 'app-pinneditems',
  templateUrl: './pinneditems.component.html',
  styleUrls: ['./pinneditems.component.css']
})
export class PinneditemsComponent implements OnInit {


  history:any= {'hits':{'hits':{}}};
   historyArray:any[] = [];
   selectedSearchItem: boolean = false;
  p=1;
  historyItem:any = [];
  searchAfterTime:any; 
  searchBeforeTime:any;
  constructor(private pinresultservice: PinResultService,private router: Router, private commonservice:CommonService) { }

  ngOnInit() {
    document.getElementById('loading').style.display="block";
   // setTimeout(() => {
     // alert();
      this.getPinDetails();
    //}, 6000);
      }
     

getPinDetails(){
  this.searchBeforeTime = Date.now();
        this.pinresultservice.getPinDetails().subscribe(res=>{
          this.history = res;
          console.log('pinned items'+JSON.stringify(this.history));
          this.historyArray = this.history.hits.hits
          for (let i = 0; i < this.historyArray.length; i++) {
            this.historyArray[i].isChecked = false;
        }
        this.searchAfterTime = Date.now();
        document.getElementById('loading').style.display="none";
      let serchTimeDiff = this.searchAfterTime - this.searchBeforeTime;
      if(this.historyArray.length == 0){
        serchTimeDiff = 0;
      }
      console.log('historyArraylength'+JSON.stringify(this.historyArray.length));
      this.commonservice.changeSearchTime({"searchTime":serchTimeDiff,"searchRecordCount": this.historyArray.length})
        //document.getElementById('loading').style.display="none";
    }, err=>{
      console.log(err);
    })
      }
    navigateToSearchResult(hist){
      console.log('hist'+JSON.stringify(hist._source.query));
      this.router.navigate(['/search-result',hist._source.query,hist._source.technology,'result','Default']);
    }
    rmoveHistoryByOne(id,index){
      this.historyArray.splice(index, 1);
      this.pinresultservice.removePinDetails(id).subscribe(res=>{
    }, err=>{
    console.log(err);
    })
    }
    clearAll(){
      this.pinresultservice.removeAllPinDetails(this.historyArray).subscribe(res=>{
        this.historyArray = [];
      }, err=>{
      console.log(err);
      })
      
    }
    selectedItem(event,Item,index){  
      //alert(event.checked);
      if(event.checked == true ){
        this.historyItem.push(Item);
        this.selectedSearchItem = true;
      }
      else{
        this.historyItem.splice(index, 1);
        this.selectedSearchItem = false;
      }
      console.log('historyItem'+JSON.stringify(this.historyItem));
    } 
    delete(){
      for(let i = 0;i<this.historyItem.length;i++){
        let index = this.historyArray.indexOf(this.historyItem[i]);
        if (index > -1) {
          this.historyArray.splice(index, 1);
          }
       }
      this.pinresultservice.removeAllPinDetails(this.historyItem).subscribe(res=>{
        //this.historyArray = [];
       // alert();  
      }, err=>{
      console.log(err);
      })
    }
    cancel(){
      for (let i = 0; i < this.historyArray.length; i++) {
        this.historyArray[i].isChecked = false;
        this.historyItem = [];
      }
    }
}
