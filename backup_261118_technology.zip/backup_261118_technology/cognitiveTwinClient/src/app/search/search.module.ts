import {NgModule} from '@angular/core';
import {searchroutedComponents, SearchRoutingModule} from './search-routing.module';
import {FormsModule} from '@angular/forms';
import {CommonModule} from '@angular/common';
import {CongitiveCommonModule} from '../common/common.module';
import {NgxPaginationModule} from 'ngx-pagination';
import {SharedModule} from '../shared/shared.module';
import { SidenavComponent } from './personalized/sidenav/sidenav.component';
import { SearchItemComponent } from './personalized/search-item/search-item.component';
import { AddComponent } from './personalized/add/add.component';
import {HistoryComponent} from './history/history.component';
import {PersonalizedComponent} from './personalized/personalized.component';
import {AdvancedComponent} from './advanced/advanced.component';
import { PinneditemsComponent } from './pinneditems/pinneditems.component';
import { UserprofileComponent } from './userprofile/userprofile.component';
import { AddknowledgeComponent } from './addknowledge/addknowledge.component';
import { NgxEditorModule } from 'ngx-editor';
import { AddanswerComponent } from './addanswer/addanswer.component';



@NgModule({
  declarations: [...searchroutedComponents, SidenavComponent, SearchItemComponent, AddComponent],
  providers: [],
  imports: [
    CommonModule,
    FormsModule,
    SearchRoutingModule,
    SharedModule,
    CongitiveCommonModule,
    NgxPaginationModule,
    NgxEditorModule],
  exports:[ PersonalizedComponent, AdvancedComponent, HistoryComponent,PinneditemsComponent,UserprofileComponent,
    AddknowledgeComponent,AddanswerComponent]

})

export class SearchModule {

}
