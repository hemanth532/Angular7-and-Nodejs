import { Component, OnInit,Input } from '@angular/core';
import { AddAnswerService } from './../../services/add-answer/addanswer.service'
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material';
import { DialogpopupComponent } from '../../dialogpopup/dialogpopup.component';

@Component({
  selector: 'app-addanswer',
  templateUrl: './addanswer.component.html',
  styleUrls: ['./addanswer.component.css']
})
export class AddanswerComponent implements OnInit {
  addAnswer:any = '';
  @Input() parentId: any;
  constructor(private addsnswerservice:AddAnswerService,public dialog: MatDialog) { }

  ngOnInit() {
  }
  addKnowledge(event){
    console.log('addAnswer,parentId'+this.addAnswer,this.parentId);
    document.getElementById('loading').style.display="block";
    this.addsnswerservice.AddAnswerDetails(this.addAnswer,this.parentId).subscribe(res=>{
      document.getElementById('loading').style.display="none";
      this.openDialog();
      this.addAnswer = '';
    }, err=>{
      document.getElementById('loading').style.display="none";
    console.log(err);
    })
  }
  openDialog(): void {
    const dialogRef = this.dialog.open(DialogpopupComponent, {
      data: 'Answer has been added sucessfully'
    });
}
}
