import { Component, OnInit } from '@angular/core';
import { TechnologiesService } from '../../services/technologies/technologies.service'
import { AddKnowledgeService } from  '../../services/add-knowledge/add-knowledge-service'
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material';
import { DialogpopupComponent } from '../../dialogpopup/dialogpopup.component';
import { CommonService } from '../../shared/services/common-service'

@Component({
  selector: 'app-addknowledge',
  templateUrl: './addknowledge.component.html',
  styleUrls: ['./addknowledge.component.css']
})
export class AddknowledgeComponent implements OnInit {
  addknowledgeobj = {};
  technologies: any = [];

  constructor(private technologiesservice:TechnologiesService, 
    private addknowledgeservice:AddKnowledgeService,public dialog: MatDialog,private commonservice:CommonService) { }

  ngOnInit() {
    this.technologiesservice.getTechnologies().subscribe(res=>{
      this.technologies  = res;
      }, 
    err=>{
          console.log(err);
      })
    }
    addKnowledge(event){
      document.getElementById('loading').style.display="block";
      this.addknowledgeservice.addKnowledgeDetails(this.addknowledgeobj).subscribe(res=>{
        document.getElementById('loading').style.display="none";
        this.openDialog();
        this.addknowledgeobj = {};
      }, err=>{
      console.log(err);
      document.getElementById('loading').style.display="none";
      })
    }
    openDialog(): void {
      const dialogRef = this.dialog.open(DialogpopupComponent, {
        data: 'Knowledge has been added sucessfully'
      });
  }
}

