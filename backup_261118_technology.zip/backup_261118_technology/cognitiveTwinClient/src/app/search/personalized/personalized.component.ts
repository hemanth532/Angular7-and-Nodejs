import { Component, OnInit,Output,EventEmitter } from '@angular/core';

@Component({
  selector: 'app-personalized',
  templateUrl: './personalized.component.html',
  styleUrls: ['./personalized.component.css']
})
export class PersonalizedComponent implements OnInit {

  selectedValue='';
  @Output() action = new EventEmitter();
  @Output() sidenavAction = new EventEmitter();
  @Output() SearchItemAction = new EventEmitter();
  searchItem:any;
  tabindex:number = 0;
  constructor() { }

  ngOnInit() {
  }
  doAction(event){
    this.action.emit(false);
  }
  doSidenavAction(item){
      console.log('item pers'+JSON.stringify(item));
      this.searchItem = item;
      //this.SearchItemAction.emit(item);
  }
  doActionUpdate(){
    this.onSelectedIndexChange(0);
  }
  onSelectedIndexChange(event){
    this.tabindex = event;
  }

}
