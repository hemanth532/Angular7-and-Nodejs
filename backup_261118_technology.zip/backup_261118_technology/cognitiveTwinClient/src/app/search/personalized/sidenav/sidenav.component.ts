import { Component, OnInit,Output,EventEmitter } from '@angular/core';
import {Router } from '@angular/router';
import { AdvancedSearchService} from '../../../services/advanced-search/advanced-search-service';
import { CommonService } from '../../../shared/services/common-service';

@Component({
  selector: 'app-personalized-sidenav',
  templateUrl: './sidenav.component.html',
  styleUrls: ['./sidenav.component.css']
})
export class SidenavComponent implements OnInit {
  searchItems:any = {};
  searchItemsArray:any[] = [];
  @Output() sidenavAction = new EventEmitter();
  Advbuttonclr:any;
  constructor(private router: Router,private AdvSearchService: AdvancedSearchService,private commonservice:CommonService) { }

  ngOnInit() {
    this.commonservice.currentMessage.subscribe(message =>{
      this.getAdvSearchDetails();
    },
    error=>{
      console.log('error'+error);
    })
  }
  selectIteam(item){
      console.log('item'+JSON.stringify(item));
      this.Advbuttonclr = item._id
      this.sidenavAction.emit(item);
  }
  getAdvSearchDetails(){
    this.AdvSearchService.getAdvSearchDetails().subscribe(response => {
      this.searchItems = response;
      console.log('this.searchItems'+JSON.stringify(this.searchItems));
      this.searchItemsArray =  this.searchItems.ret.hits.hits
      console.log('this.searchItems'+JSON.stringify(this.searchItemsArray));
    },
    error=>{
      console.log('error'+error);
    });
  }
  
  removeIteam(item,index){
    this.searchItemsArray.splice(index, 1);
    this.AdvSearchService.removeAdvSearchDetails(item).subscribe(response => {
   
    },
    error=>{
      console.log('error'+error);
    });
  }

}
