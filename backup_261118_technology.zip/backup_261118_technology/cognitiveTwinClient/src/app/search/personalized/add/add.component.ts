import {Component, OnInit, TemplateRef, ViewChild,ElementRef,Output,EventEmitter} from '@angular/core';
import {TECHNOLOGIES} from '../../../shared/constants';
import { TechnologiesService } from '../../../services/technologies/technologies.service'
import {SearchOverlayService} from '../../../shared/services/search-overlay.service';
import { AdvancedSearchService} from '../../../services/advanced-search/advanced-search-service';
import {Router } from '@angular/router';
import { CommonService } from '../../../shared/services/common-service';

@Component({
  selector: 'app-add-personalized-search',
  templateUrl: './add.component.html',
  styleUrls: ['./add.component.css']
})
export class AddComponent implements OnInit {

  suggested_terms = new Set<{ active: boolean, tagName: string }>();

  technologies:any = [];
  selectedValue=''
  @ViewChild('modalConnectedElement') modalConnectedElement: ElementRef;
  @ViewChild('advance_search') advanceSearch: TemplateRef<any>;
  addSearchCheck: string;
  AddPersonalizedObj: any = {};
  @Output() action = new EventEmitter();
  @Output() actionUpdate = new EventEmitter();
  

  constructor(private previewDialog: SearchOverlayService, private router: Router,
    private AdvSearchService: AdvancedSearchService,private commonservice:CommonService,
    private technologiesservice:TechnologiesService) {
  }

  ngOnInit() {
    this.technologiesservice.getTechnologies().subscribe(res=>{
     
      this.technologies  = res;
  }, err=>{
    
    console.log(err);
  })
    this.suggested_terms.add({active: false, tagName: 'AWS'});
    this.suggested_terms.add({active: false, tagName: 'S3'});
    this.suggested_terms.add({active: false, tagName: 'Subnet'});
  }
  advanceSearchHandler() {
    /*this.previewDialog.open({
      connectedElement: this.modalConnectedElement,
      templateRef: this.advanceSearch
    });*/
    if(this.AddPersonalizedObj.addSearchCheck == 'Yes'){
      this.AdvSearchService.createAdvSearchDetails(this.AddPersonalizedObj).subscribe(response => {
         // this.action.emit(false);
         this.actionUpdate.emit();
         this.commonservice.changeMessage("Hello from Sibling")
          this.AddPersonalizedObj = {};
      },
      error=>{
        console.log('error'+error);
      });
    }
    else{
    this.router.navigate(['/search-result',this.AddPersonalizedObj.SearchQuery,this.AddPersonalizedObj.techoologies,'result','Default']);
    this.action.emit(false);
    this.AddPersonalizedObj = {};
    }
  }
}
