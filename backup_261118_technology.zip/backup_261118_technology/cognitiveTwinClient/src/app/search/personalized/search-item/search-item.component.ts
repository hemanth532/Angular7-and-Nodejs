import { Component, OnInit,Input,Output,EventEmitter } from '@angular/core';
import {TECHNOLOGIES} from '../../../shared/constants';
import { TechnologiesService } from '../../../services/technologies/technologies.service'
import { AdvancedSearchService} from '../../../services/advanced-search/advanced-search-service';
import {Router } from '@angular/router';

@Component({
  selector: 'app-personalized-search-item',
  templateUrl: './search-item.component.html',
  styleUrls: ['./search-item.component.css']
})
export class SearchItemComponent implements OnInit {
  suggested_terms = new Set<{ active: boolean, tagName: string }>();

  technologies:any = [];
  selectedValue=''
  @Input() SearchItemAction :any = {}; 
  @Output() action = new EventEmitter();
  constructor(private router: Router,private AdvSearchService: AdvancedSearchService,private technologiesservice:TechnologiesService) {
  }

  ngOnInit() {
    this.technologiesservice.getTechnologies().subscribe(res=>{
     
      this.technologies  = res;
  }, err=>{
    
    console.log(err);
  })
    this.suggested_terms.add({active: false, tagName: 'AWS'});
    this.suggested_terms.add({active: false, tagName: 'S3'});
    this.suggested_terms.add({active: false, tagName: 'Subnet'});
    
  }
  /*doSearchItemAction(item){
    alert(item);
      console.log('item result'+JSON.stringify(item));
  }*/
  search(searchItem){
    this.router.navigate(['/search-result',searchItem._source.query,searchItem._source.technology,'result','Default']);
    this.action.emit(false);
  }
  update(searchItem){
      this.AdvSearchService.updateAdvSearchDetails(searchItem).subscribe(response => {
        //alert('true');
        this.action.emit(false);
    },
    error=>{
      console.log('error'+error);
    });
  }
}
