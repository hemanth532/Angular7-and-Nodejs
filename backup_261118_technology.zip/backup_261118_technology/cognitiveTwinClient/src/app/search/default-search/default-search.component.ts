import {AfterViewInit, Component, ElementRef, OnInit, TemplateRef, ViewChild} from '@angular/core';

import {Http} from '@angular/http';
import {Router} from '@angular/router';
import {AuthHttp} from 'angular2-jwt';
import {jwt_decode} from 'jwt-decode';

import {Client} from 'elasticsearch';

import {error} from 'selenium-webdriver';
import {ElacticSearchService} from '../../services/elastic-search/elactic-search.service';
import {LoginService} from '../../services/login/login.service';
import {TECHNOLOGIES} from '../../shared/constants';
import { TechnologiesService } from '../../services/technologies/technologies.service'
import {SearchOverlayService} from '../../shared/services/search-overlay.service';
import {JetAirwaysService} from '../../services/jetairways/jetairways-service'
declare var responsiveVoice:any;

@Component({
  selector: 'app-search',
  templateUrl: './default-search.component.html',
  styleUrls: ['./default-search.component.css']
})
export class DefaultSearchComponent implements OnInit, AfterViewInit {
  tech = '';
  query = '';
  username;
  searchControl = '';
  selectedValue = '';
  AreaControl = '';
  queryAreaControl = '';
  queryppmsModel = '';
  showPersonalizedFlag = false;
  togglePersonalized: boolean = false;
  accessabilityVoice: boolean = false;
  project: number = 0;
  selectedArea;
  areaQuery;
  tabSelected:any = 'Default';
  clientQuestion = new Client({
    hosts: 'http://13.229.170.87:9200/'
  });

  clientAnswers = new Client({
    hosts: 'http://13.229.170.87:9200/'
  });

  @ViewChild('modalConnectedElement') modalConnectedElement: ElementRef;
  @ViewChild('personalized_search') personalizedSearch: TemplateRef<any>;
  @ViewChild('search_history') searchHistory: TemplateRef<any>;
  @ViewChild('advance_search') advanceSearch: TemplateRef<any>;

  jwt: string;
  decodedJwt: string;
  response: string;
  api: string;

  questionsObj = [];
  answersObj = [];

  questionJson = {};
  answerJson = {};
  airwayareas:any = [];
  Suggested_terms = new Set<{ active: boolean, tagName: string }>();

  technologies:any = [];
  projectName = localStorage.getItem('projectName');
  defaultPro = localStorage.getItem('default');

  constructor(private user: LoginService,
              public router: Router,
              private ec: ElacticSearchService,
              private previewDialog: SearchOverlayService,
              private technologiesservice:TechnologiesService,
              private jetairwayservice:JetAirwaysService) {
    this.jwt = localStorage.getItem('token');
    //this.decodedJwt = this.jwt && jwt_decode(this.jwt);
  }

  ngOnInit() {
    
 if(localStorage.getItem('accessabilityVoice') == 'true'){
  this.accessabilityVoice = true;
  responsiveVoice.speak('Welcome to Congnitive Cloud','US English Female');
}
if(this.projectName == 'default' ){
  //alert('yes')
  this.defaultPro = 'yes';
}
if(this.defaultPro == 'no'){
  this.project = 1;
}

    //this.username = this.user.get_username();
    this.username = localStorage.getItem('userName')
    console.log(' this.username'+ this.username);


    /*this.ec.get_Suggested_terms().subscribe(res => {
      res.forEach(val => {
        this.Suggested_terms.add({active: false, tagName: val});
      });
    });*/
    this.technologiesservice.getTechnologies().subscribe(res=>{
     
    this.technologies  = res;
}, err=>{
  
  console.log(err);
})
this.getAirwayAreas();
  }
  logout() {
    if(localStorage.getItem('accessabilityVoice') == 'true'){
    responsiveVoice.speak('You are signing off','US English Female');
    }
    localStorage.removeItem('token');
    localStorage.removeItem("userName");
    localStorage.removeItem("userId");
    this.user.setUserLoggedIn(false);
    this.router.navigate(['login']);
  }
getAirwayAreas(){
  this.jetairwayservice.getAirwaysAreas().subscribe(res=>{
    this.airwayareas = res;
}, err=>{
  
  console.log(err);
})
}
  sortByOpt = [
    {value: 'java', viewValue: 'java'},
    {value: 'python', viewValue: 'python'},
    {value: 'R', viewValue: 'R'}
  ];

  search_query() {
    this.router.navigate(['search-result']);
  }

  change_query_results(ques, ans) {
    this.questionsObj = ques;
    this.answersObj = ans;
  }


  set_Suggested_terms(term) {
   // this.ec.query_suggested_terms(term);
    //console.log(this.Suggested_terms);
    return true;
  }

  elastic_search_query(event, query,techoologies) {
    if(localStorage.getItem('accessabilityVoice') == 'true'){
    let voiceQuery  = "Searching "+query;
    responsiveVoice.speak(voiceQuery,'US English Female');
    }
    event.preventDefault();
    //alert(query+'-->'+techoologies);
    //this.ec.set_query(query);
    this.goToSearchResult(query,techoologies);
    /* this.ec.getAndSetQueAndAnswers().then(res=>{
       this.goToSearchResult();
     });*/
  }

  ngAfterViewInit() {
    // this.previewDialog.open({connectedElement: this.modalConnectedElement});
  }

  /*get_search_history() {
    console.log(this.username);
    //var search_history = this.ec.get_search_history(this.username);
    console.log(this.ec.get_search_history(this.username));
    //console.log(search_history);
    this.router.navigate(['search']);
  }*/

  goToSearchResult(query,technologies) {
    //this.router.navigate(['search-result']);
    //this.router.navigate(['search-result',this.selectedAssessment.assessmentId]);
    if(this.defaultPro == 'no'){
      this.tabSelected = localStorage.getItem('projectName');
    }
    this.router.navigate(['/search-result',query,technologies,'result',this.tabSelected]);
  }

  highLightSelectedTag(idx) {
    console.log(idx);
    let suggestedArr = Array.from(this.Suggested_terms);
    let oldElementValue = suggestedArr[idx];
    let updatedArr = suggestedArr.map((item, index) => {
      let updatedElementValue = {...item, active: false};
      if (index === idx) {
        updatedElementValue = {...item, active: true};
      }

      /* if (index !== idx) {
         return item;
       }*/

      //  return an updated value
      return {
        ...item,
        ...updatedElementValue
      };
    });
    this.Suggested_terms = new Set(updatedArr);

  }

  showPersonalized() {
    // this.showPersonalizedFlag = !this.showPersonalizedFlag;
    /*this.previewDialog.open({
      connectedElement: this.modalConnectedElement,
      templateRef: this.personalizedSearch
    });*/
    this.togglePersonalized = !this.togglePersonalized;
  }
  doAction(AssObj: any){
   // alert('called');
    this.togglePersonalized = AssObj;
  }
  showHistory() {
    this.previewDialog.open({
      connectedElement: this.modalConnectedElement,
      templateRef: this.searchHistory
    });
  }

  advanceSearchHandler() {
    this.previewDialog.open({
      connectedElement: this.modalConnectedElement,
      templateRef: this.advanceSearch
    });
  }
  pageSelected(page){
    this.router.navigate(['/search-result',page]);
  }
  accessabilityChange(event){
    this.accessabilityVoice = event.checked;
    let abc = JSON.stringify(this.accessabilityVoice);
    localStorage.setItem('accessabilityVoice',abc);
  }
  tabClicked(event){
    //this.project = tab;
    if(event.index == 0){
      this.project = 0;
      this.tabSelected = 'Default'
    } 
    else if(event.index == 1){
      this.project = 1;
      this.tabSelected = localStorage.getItem('projectName');
    }
    }
}
