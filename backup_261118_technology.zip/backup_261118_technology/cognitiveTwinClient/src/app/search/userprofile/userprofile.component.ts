import { Component, OnInit } from '@angular/core';
import { ProfileService } from '../../services/profile/profile.service'
import {CommonService } from '../../shared/services/common-service';

@Component({
  selector: 'app-userprofile',
  templateUrl: './userprofile.component.html',
  styleUrls: ['./userprofile.component.css']
})
export class UserprofileComponent implements OnInit {
  profile:any;
  searchAfterTime:any;
  searchBeforeTime:any;
  constructor(private profileservice : ProfileService,private commonservice:CommonService) { }

  ngOnInit() {
    this.searchBeforeTime = Date.now();
    this.profileservice.getProfileDetails().subscribe(res=>{
        this.profile = res;
        this.searchAfterTime = Date.now();
        let serchTimeDiff = this.searchAfterTime - this.searchBeforeTime;
     //this.commonservice.changeSearchTime({"searchTime":0,"searchRecordCount": 0})
        console.log('this.profile'+JSON.stringify(this.profile));
    }, err=>{
    console.log(err);
    })
   // this.commonservice.changeSeletectedTech('Default');
  }

}
