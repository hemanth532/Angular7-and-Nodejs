import { SectionLabelDirective } from './section-label.directive';

describe('SectionLabelDirective', () => {
  it('should create an instance', () => {
    const directive = new SectionLabelDirective();
    expect(directive).toBeTruthy();
  });
});
