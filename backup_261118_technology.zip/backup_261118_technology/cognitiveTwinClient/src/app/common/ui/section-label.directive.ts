import { Directive } from '@angular/core';

@Directive({
  selector: '[sectionLabel]',
  host: {
    '[style.background-color]': '"#cccccc"',
    '[style.padding]': '"5px"',
  }
})
export class SectionLabelDirective {

  constructor() { }

}
