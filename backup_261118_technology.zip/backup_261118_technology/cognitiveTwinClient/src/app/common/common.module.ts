import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RatingComponent } from './ui/rating/rating.component';
import { SectionLabelDirective } from './ui/section-label.directive';


@NgModule({
  imports: [
    CommonModule
  ],
  declarations: [RatingComponent, SectionLabelDirective],
  exports:[RatingComponent,SectionLabelDirective]
})
export class CongitiveCommonModule { }
