import { Component, OnInit,TemplateRef, ViewChild,ElementRef,HostListener} from '@angular/core';
import { Router } from '@angular/router';
import {LoginService} from '../services/login/login.service';
import {SearchOverlayService} from './../shared/services/search-overlay.service';
import { CookieService } from 'angular2-cookie/services/cookies.service';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material';
import { DialogpopupComponent } from './../dialogpopup/dialogpopup.component';
declare var responsiveVoice:any;
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  name = "Rajat";
  private loginUserName = "";
  private loginPassword = "";
  loginObj: any = {};
  hide = true;
  screenHeight :any
  projectDetails:any = ['Service Transformation Team','NEXT Labs','JP Morgan','Tower Gate'];
  @ViewChild('modalConnectedElement') modalConnectedElement: ElementRef;
  @ViewChild('invalid_login') invalidlogin: TemplateRef<any>;
  @ViewChild('siteunder_maintance') siteundermaintance: TemplateRef<any>;
  customErrorMessage: any
  accessabilityVoice: boolean = false;
  constructor( private router: Router, private loginservice: LoginService,
    private previewDialog: SearchOverlayService,private _cookieService:CookieService,public dialog: MatDialog) { }

  ngOnInit() {
    if(this._cookieService.get('remember')){
      this.loginObj.username=this._cookieService.get('username');
      this.loginObj.password=this._cookieService.get('password');
      this.loginObj.remember=this._cookieService.get('remember');
   }
   if(localStorage.getItem('accessabilityVoice') == 'true'){
      this.accessabilityVoice = true;
   }
    this.onResize(event);
    
  }

  public greetings(){
    return "Hi" + this.name;
  }

  public showDetails(name,pwd){
    //console.log(name);
    //console.log(pwd);
    //console.log("logged");
    if(name==this.loginUserName && pwd == this.loginPassword ){
      this.loginservice.setUserLoggedIn(true);
      this.router.navigate(['search']);
    }
    else{
      this.router.navigate(['login']);
    }
  }

  login(event, username, password,project) {
    event.preventDefault();
    console.log(username);
    console.log(password);
    this.loginUserName = event.target[0].value;
    this.loginPassword = event.target[1].value;
    this.loginservice.set_username(username);
    let body = JSON.stringify({ username, password, project });
    return this.loginservice.login(body)
      .subscribe(response => {
      if(response['success']){
       // alert(response['token'] +''+response['userFname']+''+response['userId']);
        localStorage.setItem('token', response['token']);
        localStorage.setItem('userName', response['userFname']);
        localStorage.setItem('userId', response['userId']);
        localStorage.setItem('projectName', response['projectName']);
        //localStorage.setItem('projectName', 'ppms'); //Jet Airways //ppms
        localStorage.setItem('supervisorName', response['supervisorName']);
        //localStorage.setItem('default', 'no'); //yes //no
        localStorage.setItem('default', response['default']);
        if(this.loginObj.remember){
          this._cookieService.put('username',this.loginObj.username);
          this._cookieService.put('password',this.loginObj.password);
          this._cookieService.put('remember',this.loginObj.remember);
        }
        else{
          this._cookieService.remove('username');
          this._cookieService.remove('password');
          this._cookieService.remove('remember');
        }
          this.router.navigate(['search']);
      }
       else{
         this.customErrorMessage = response['message'];
        /*this.previewDialog.open({
          connectedElement: this.modalConnectedElement,
          templateRef: this.invalidlogin
        });*/
        this.openDialog();
       }
      },
      error=>{
        console.log('error'+error);
      }
    );
  }
mphasisLogin(){
  if(localStorage.getItem('accessabilityVoice') == 'true'){
  responsiveVoice.speak('Site is undermaintance','US English Female');
  }
  //this.router.navigate(['undermaintance']);
  this.previewDialog.open({
    connectedElement: this.modalConnectedElement,
    templateRef: this.siteundermaintance
  });
}
 
@HostListener('window:resize', ['$event'])
onResize(event?) {
  //alert();
this.screenHeight = window.innerHeight;
    }
selectedItem(event){
    this.loginObj.remember = event.checked;
}
accessabilityChange(event){
  this.accessabilityVoice = event.checked;
  console.log(this.accessabilityVoice);
  let abc = JSON.stringify(this.accessabilityVoice);
  localStorage.setItem('accessabilityVoice',abc);
 // console.log(this.accessabilityVoice);
}
openDialog(): void {
  const dialogRef = this.dialog.open(DialogpopupComponent, {
    data: this.customErrorMessage
  });

  dialogRef.afterClosed().subscribe(result => {
    console.log('The dialog was closed');
  });
}
}

