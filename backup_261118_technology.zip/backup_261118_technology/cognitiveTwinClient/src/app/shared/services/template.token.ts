import {InjectionToken, TemplateRef} from '@angular/core';

export const TEMPLATE_DATA = new InjectionToken<TemplateRef<any>>('templateData');
