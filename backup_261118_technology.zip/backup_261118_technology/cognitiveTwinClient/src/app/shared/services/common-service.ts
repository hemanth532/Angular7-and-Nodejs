import {Injectable} from "@angular/core";
import {HttpClient} from "@angular/common/http";
import "rxjs/add/operator/map";
import { BehaviorSubject } from 'rxjs';
import { environment } from '../../../environments/environment';

@Injectable()
export class CommonService {

  basePath: string = environment.apiUrl;
  
  private messageSource = new BehaviorSubject('default message');
  currentMessage = this.messageSource.asObservable();

  private selectedTermSource = new BehaviorSubject([]);
  currentselectedTermSource = this.selectedTermSource.asObservable();

  private questionNAnserSource = new BehaviorSubject('default message');
  currentquestionNAnserSource = this.questionNAnserSource.asObservable();

  private searchTimeSource = new BehaviorSubject({"searchTime":0,"searchRecordCount":0});
  currentSearchTimeSource = this.searchTimeSource.asObservable();

  private seletectedTechSource = new BehaviorSubject('');
  currentseletectedTechSource = this.seletectedTechSource.asObservable();

  private updatePageValSource = new BehaviorSubject(1);
  currentupdatePageValSource = this.updatePageValSource.asObservable();

  private seletectedFilterSource = new BehaviorSubject('Default');
  currentseletectedFilterSource = this.seletectedFilterSource.asObservable();

  private responseFilterSource = new BehaviorSubject([]);
  currentresponseFilterSource = this.responseFilterSource.asObservable();
  private responseJetFilterSource = new BehaviorSubject([]);
  currentresponseJetFilterSource = this.responseJetFilterSource.asObservable();

  constructor(private http: HttpClient) {}
  
  changeMessage(message: string) {
    this.messageSource.next(message)
  }
  changeSelectedTerm(message: any) {
    this.selectedTermSource.next(message)
  }
  changeQuestionNAnser(message: any) {
    this.questionNAnserSource.next(message)
  }
  changeSearchTime(message: any) {
    this.searchTimeSource.next(message)
  }
  changeSeletectedTech(message: any) {
   // alert(message);
    this.seletectedTechSource.next(message)
  }
  changeupdatePageVal(message: any) {
    this.updatePageValSource.next(message)
  }
  changeSeletectedFilter(message: any) {
    this.seletectedFilterSource.next(message)
  }
  changeResponseFilterSource(message: any) {
    this.responseFilterSource.next(message)
  }
  changeResponseJetFilterSource(message: any) {
    this.responseJetFilterSource.next(message)
  }
  

}
