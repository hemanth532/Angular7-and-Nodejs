import { TestBed, inject } from '@angular/core/testing';

import { SearchOverlayService } from './search-overlay.service';

describe('SearchOverlayService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [SearchOverlayService]
    });
  });

  it('should be created', inject([SearchOverlayService], (service: SearchOverlayService) => {
    expect(service).toBeTruthy();
  }));
});
