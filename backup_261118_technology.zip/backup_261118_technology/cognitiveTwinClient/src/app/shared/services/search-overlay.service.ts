import {ComponentRef, ElementRef, Injectable, InjectionToken, Injector, TemplateRef} from '@angular/core';
import {Overlay, OverlayConfig, OverlayRef} from '@angular/cdk/overlay';
import {ComponentPortal, PortalInjector} from '@angular/cdk/portal';
import {SearchOverlayComponent} from '../search-overlay/search-overlay.component';
import {CustomOverlayRef} from './custom-overlay.ref';
import {TEMPLATE_DATA} from './template.token';
import {CdkScrollable} from '@angular/cdk/scrolling';


interface DialogConfig {
  panelClass?: string;
  hasBackdrop?: boolean;
  backdropClass?: string;
  connectedElement: ElementRef;
  templateRef?: TemplateRef<any>;
  width?: string;
  height?: string;
}

const DEFAULT_CONFIG: DialogConfig = {
  hasBackdrop: true,
  backdropClass: 'dark-backdrop',
  panelClass: 'file-preview-dialog-panel',
  connectedElement: new ElementRef('body')
};


@Injectable()
export class SearchOverlayService {

  constructor(private injector: Injector,
              private overlay: Overlay) {
  }

  open(config: DialogConfig = {connectedElement: new ElementRef('body')}) {
    // Override default configuration
    const dialogConfig = {...DEFAULT_CONFIG, ...config};

    // Returns an OverlayRef which is a PortalHost
    const overlayRef = this.createOverlay(dialogConfig);

    // Instantiate remote control
    const dialogRef = new CustomOverlayRef(overlayRef);

    const overlayComponent = this.attachDialogContainer(overlayRef, dialogConfig, dialogRef);

    overlayRef.backdropClick().subscribe(_ => dialogRef.close());

    return dialogRef;
  }

  private attachDialogContainer(overlayRef: OverlayRef, config: DialogConfig, dialogRef: CustomOverlayRef) {
    const injector = this.createInjector(config, dialogRef);

    const containerPortal = new ComponentPortal(SearchOverlayComponent, null, injector);
    const containerRef: ComponentRef<SearchOverlayComponent> = overlayRef.attach(containerPortal);

    return containerRef.instance;
  }

  private createInjector(config: DialogConfig, dialogRef: CustomOverlayRef): PortalInjector {
    const injectionTokens = new WeakMap();

    injectionTokens.set(CustomOverlayRef, dialogRef);
    injectionTokens.set(TEMPLATE_DATA, config.templateRef);

    return new PortalInjector(this.injector, injectionTokens);
  }


  private createOverlay(config: DialogConfig) {
    const overlayConfig = this.getOverlayConfig(config);
    return this.overlay.create(overlayConfig);
  }


  private getOverlayConfig(config: DialogConfig): OverlayConfig {
    const positionStrategy = this.overlay.position()
      .global()
      .centerHorizontally()
      .centerVertically();
     //.connectedTo(config.connectedElement, {originX: 'start', originY: 'bottom'}, {overlayX: 'start', overlayY: 'top'})
    //  .withScrollableContainers([new CdkScrollable()]);


    const overlayConfig = new OverlayConfig({
      hasBackdrop: config.hasBackdrop,
      backdropClass: config.backdropClass,
      panelClass: config.panelClass,
    //   scrollStrategy: this.overlay.scrollStrategies.reposition({scrollThrottle:300}),
    /*  width: '450px',
      height: '400px',*/
      positionStrategy
    });

    return overlayConfig;
  }


}
