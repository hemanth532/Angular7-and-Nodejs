import {Component, Inject, OnInit} from '@angular/core';
import {TEMPLATE_DATA} from '../services/template.token';


@Component({
  selector: 'app-search-overlay',
  templateUrl: './search-overlay.component.html',
  styleUrls: ['./search-overlay.component.css']
})
export class SearchOverlayComponent implements OnInit {

  constructor( @Inject(TEMPLATE_DATA) public template: any) { }

  ngOnInit() {
    console.log(this.template);
  }

}
