export const TECHNOLOGIES =  [
  {value: 'android', viewValue: 'Android'},
  {value: 'asp', viewValue: 'Asp.Net'},
  {value: 'c', viewValue: 'C'},
  {value: 'c#', viewValue: 'C#'},
  {value: 'css', viewValue: 'CSS'},
  {value: 'html', viewValue: 'HTML'},
  {value: 'ios', viewValue: 'IOS'},
  {value: 'java', viewValue: 'Java'},
  {value: 'javascript', viewValue: 'JavaScript'},
  {value: 'jquery', viewValue: 'JQuery'},
  {value: 'php', viewValue: 'PhP'},
  {value: 'python', viewValue: 'Python'},
  {value: 'ruby', viewValue: 'RubyOnRails'},
  {value: 'sql', viewValue: 'SQL'}
];


