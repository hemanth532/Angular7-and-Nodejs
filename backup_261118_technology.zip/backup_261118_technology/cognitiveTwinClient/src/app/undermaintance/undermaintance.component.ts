import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-undermaintance',
  templateUrl: './undermaintance.component.html',
  styleUrls: ['./undermaintance.component.css']
})
export class UndermaintanceComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
