# HelloWorld

This project was generated with [Angular CLI](https://github.com/angular/angular-cli) version 1.7.3.

## Development server

Run `ng serve` for a dev server. Navigate to `http://localhost:4200/`. The app will automatically reload if you change any of the source files.

## Code scaffolding

Run `ng generate component component-name` to generate a new component. You can also use `ng generate directive|pipe|service|class|guard|interface|enum|module`.

## Build

Run `ng build` to build the project. The build artifacts will be stored in the `dist/` directory. Use the `-prod` flag for a production build.

## Running unit tests

Run `ng test` to execute the unit tests via [Karma](https://karma-runner.github.io).

## Running end-to-end tests

Run `ng e2e` to execute the end-to-end tests via [Protractor](http://www.protractortest.org/).

## Further help

To get more help on the Angular CLI use `ng help` or go check out the [Angular CLI README](https://github.com/angular/angular-cli/blob/master/README.md).




### Developed/features developed
===================================

#### Registration Page
  
  
     * Sign Up Component is crated for this
     * it can be navigated from login page by click action of create an action button 
     
#### Search result page is created and completed. It is integrated with elasticsearch end point as well
  
#### Personalized search page and add search personalized component is created

#### Personalized search page can be opened from search page as well search results page on click of respective button.
    
   * It will be shown in a overlay. The same is applicable for search history and advance search.  
   * Personalized component created and inside the search folder
   * add personalized component which is inside  the folder as mentioned below
                                                  -- search
                                                       -- personalized
                                                               -- add
                                                
   
#### Reusable Overlay component is created which is in shared folder
   * It is a dynamic component
   * we can pass template ref to render the content
   * Personalized and add personalized search is created this way
   * Search history component is created and integarted with elastic search
   
 TODO:
 
  * Need to integrate the registration service for sign up page
  * Need to integrate the service for personalize search fetch and adding new personalize search
  * Need to develop the UI for advance search and integrate the service
  * Need to pass the technology value to the api from the search page.
  * Fetch new data for the pagination for results and history
  

